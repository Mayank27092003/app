/**
 * Socket Service
 * @format
 */

import { io, Socket } from 'socket.io-client';
import { store } from '@app/redux';
import { setJobs, setDrivers } from '@app/module/common';
import { showMessage } from 'react-native-flash-message';
import { BASE_URL } from '@app/configs';

class SocketService {
  private socket: Socket | null = null;
  private isConnected = false;

  /**
   * Initialize socket connection
   */
  connect(token?: string) {
    console.log("connect token", token);
    if (this.socket?.connected) {
      console.log('Socket already connected');
      return;
    }

    try {
      // Extract the base domain from BASE_URL for socket connection
      const socketUrl = BASE_URL.replace('/api/v1', ''); // Remove /api/v1 for socket
      
      console.log('🔌 Attempting to connect to:', socketUrl);
      console.log('🔌 Original BASE_URL:', BASE_URL);
      console.log('🔌 Token provided:', !!token);
      if (token) {
        console.log('🔌 Token length:', token.length);
        console.log('🔌 Token preview:', token.substring(0, 20) + '...');
      }
      
      // Try multiple connection strategies
      const connectionOptions = {
        // Send token in headers as requested by backend dev
        extraHeaders: token ? {
          'Authorization': `Bearer ${token}`,
          'token': token
        } : undefined,
        transports: ['polling', 'websocket'], // Try polling first, then websocket
        timeout: 10000,
        forceNew: true,
        autoConnect: true,
        reconnection: true,
        reconnectionAttempts: 5,
        reconnectionDelay: 1000,
        // Additional options to handle namespace issues
        path: '',
        upgrade: true,
        rememberUpgrade: false,
      };
      
      console.log('🔌 Connection options:', connectionOptions);
      
      this.socket = io(socketUrl, connectionOptions);

      this.setupEventListeners();
      
      console.log('Socket connection initiated');
    } catch (error) {
      console.error('Socket connection error:', error);
    }
  }

  /**
   * Setup socket event listeners
   */
  private setupEventListeners() {
    if (!this.socket) return;

    // Connection events
    this.socket.on('connect', () => {
      console.log('🔌 Socket connected:', this.socket?.id);
      console.log('🔌 Transport:', this.socket?.io.engine.transport.name);
      console.log('🔌 Socket connected successfully');
      this.isConnected = true;
    });

    this.socket.on('disconnect', (reason) => {
      console.log('🔌 Socket disconnected:', reason);
      this.isConnected = false;
    });

    this.socket.on('connect_error', (error) => {
      console.error('🔌 Socket connection error:', error);
      console.error('🔌 Error message:', error.message);
      this.isConnected = false;
    });

    this.socket.on('error', (error) => {
      console.error('🔌 Socket error:', error);
    });

    this.socket.on('reconnect', (attemptNumber) => {
      console.log('🔌 Socket reconnected after', attemptNumber, 'attempts');
      this.isConnected = true;
    });

    this.socket.on('reconnect_attempt', (attemptNumber) => {
      console.log('🔌 Socket reconnection attempt:', attemptNumber);
    });

    this.socket.on('reconnect_error', (error) => {
      console.error('🔌 Socket reconnection error:', error);
    });

    this.socket.on('reconnect_failed', () => {
      console.error('🔌 Socket reconnection failed');
      this.isConnected = false;
    });


    // Job events - Backend confirmed events
    this.socket.on('job:new', (data) => {
      console.log('🆕 job:new event received:', data);
      this.handleNewJob(data);
    });

    this.socket.on('job:created', (data) => {
      console.log('🆕 job:created event received:', data);
      this.handleNewJob(data.job || data);
    });

    this.socket.on('job:assigned', (data) => {
      console.log('✅ job:assigned event received:', data);
      console.log('✅ job:assigned data type:', typeof data);
      console.log('✅ job:assigned data keys:', data ? Object.keys(data) : 'null/undefined');
      this.handleJobAssigned(data);
    });

    // Alternative event names that might be used
    this.socket.on('job:assignment', (data) => {
      console.log('✅ job:assignment event received:', data);
      this.handleJobAssigned(data);
    });

    this.socket.on('driver:assigned', (data) => {
      console.log('✅ driver:assigned event received:', data);
      this.handleJobAssigned(data);
    });

    // Chat events
    this.socket.on('new_message', (data) => {
      console.log('💬 new_message event received:', data);
      this.handleNewMessage(data);
    });

    // Log all registered events for debugging
    console.log('🔌 Socket event listeners registered:', [
      'connect', 'disconnect', 'connect_error', 'error',
      'job:new', 'job:created', 'job:assigned', 'job:assignment', 'driver:assigned',
      'driver:available', 'driver:unavailable', 'driver:location',
      'notification:new', 'message:new', 'new_message', 'call:incoming', 'call:ended',
      'online_users_list', 'online_users_updated'
    ]);

    // Driver events
    this.socket.on('driver:available', (data) => {
      console.log('Driver available:', data);
      this.handleDriverAvailable(data);
    });

    this.socket.on('driver:unavailable', (data) => {
      console.log('Driver unavailable:', data);
      this.handleDriverUnavailable(data);
    });

    // Online users events for chat
    this.socket.on('online_users_list', (data) => {
      console.log('👥 online_users_list event received:', data);
      this.handleOnlineUserList(data);
    });

    this.socket.on('online_users_updated', (data) => {
      console.log('👥 online_users_updated event received:', data);
      this.handleOnlineUsersUpdated(data);
    });
  }

  /**
   * Handle new job event
   */
  private handleNewJob(jobData: any) {
    try {
      console.log('🆕 Processing new job:', jobData);
      
      if (!store) {
        console.error('❌ Store is not available');
        return;
      }
      
      const currentState = store.getState();
      const currentJobs = currentState.commonReducer.jobs || [];
      
      // Ensure jobData has required fields
      const processedJob = {
        id: jobData.id || jobData._id || Date.now().toString(),
        title: jobData.title || jobData.jobTitle || 'New Job',
        description: jobData.description || jobData.jobDescription || '',
        status: jobData.status || 'active',
        payAmount: jobData.payAmount || jobData.compensation || 0,
        location: jobData.location || jobData.pickupLocation || '',
        createdAt: jobData.createdAt || new Date().toISOString(),
        ...jobData // Include all other fields from backend
      };
      
      // Check if job already exists to prevent duplicates
      const existingJobIndex = currentJobs.findIndex(job => 
        job.id === processedJob.id || 
        (job._id && job._id === processedJob.id) ||
        (job.id && job.id === processedJob._id)
      );
      
      let updatedJobs;
      if (existingJobIndex !== -1) {
        // Update existing job
        updatedJobs = [...currentJobs];
        updatedJobs[existingJobIndex] = { ...updatedJobs[existingJobIndex], ...processedJob };
        console.log('🔄 Updated existing job in store');
      } else {
        // Add new job to the beginning of the list
        updatedJobs = [processedJob, ...currentJobs];
        console.log('➕ Added new job to store');
      }
      
      // Update Redux store
      store.dispatch(setJobs(updatedJobs));
      
      // Show notification only for new jobs
      if (existingJobIndex === -1) {
        showMessage({
          message: "New Job Available",
          description: `A new job has been posted: ${processedJob.title}`,
          type: "info",
          duration: 4000,
        });
      }
      
      console.log('✅ Job list updated in store. Total jobs:', updatedJobs.length);
    } catch (error) {
      console.error('❌ Error handling new job:', error);
    }
  }

  /**
   * Handle job assigned event
   */
  private handleJobAssigned(assignmentData: any) {
    try {
      console.log('✅ Processing job assignment:', assignmentData);
      
      if (!store) {
        console.error('❌ Store is not available');
        return;
      }
      
      const { 
        jobId, 
        driverId, 
        driverName,
        job_id,
        driver_id,
        driver_name,
        assignedDriverId,
        assignedDriverName,
        job,
        driver
      } = assignmentData;
      
      // Handle different possible field names from backend
      const actualJobId = jobId || job_id || job?.id || job?._id;
      const actualDriverId = driverId || driver_id || assignedDriverId || driver?.id || driver?._id;
      const actualDriverName = driverName || driver_name || assignedDriverName || driver?.name || driver?.userName || 'Unknown Driver';
      
      console.log('✅ Job assignment details:', {
        jobId: actualJobId,
        driverId: actualDriverId,
        driverName: actualDriverName
      });
      
      const currentState = store.getState();
      const currentJobs = currentState.commonReducer.jobs || [];
      
      // Update the specific job with assignment info
      const updatedJobs = currentJobs.map((jobItem: any) => {
        if (jobItem.id === actualJobId || jobItem._id === actualJobId) {
          const updatedJob = {
            ...jobItem,
            assignedDriverId: actualDriverId,
            assignedDriverName: actualDriverName,
            status: 'assigned',
            assignedAt: new Date().toISOString(),
            // Update contract participants if available
            ...(job?.jobApplications?.[0]?.contracts?.[0]?.contractParticipants && {
              jobApplications: [{
                ...job.jobApplications[0],
                contracts: [{
                  ...job.jobApplications[0].contracts[0],
                  contractParticipants: [
                    ...job.jobApplications[0].contracts[0].contractParticipants,
                    {
                      id: `driver-${actualDriverId}`,
                      userId: actualDriverId,
                      userName: actualDriverName,
                      role: 'driver',
                      status: 'assigned',
                      assignedAt: new Date().toISOString()
                    }
                  ]
                }]
              }]
            })
          };
          console.log('✅ Updated job with assignment:', updatedJob);
          return updatedJob;
        }
        return jobItem;
      });
      
      // Update Redux store
      store.dispatch(setJobs(updatedJobs));
      
      // Show notification
      showMessage({
        message: "Job Assigned",
        description: `Job has been assigned to ${actualDriverName}`,
        type: "success",
        duration: 4000,
      });
      
      console.log('✅ Job assignment updated in store successfully');
    } catch (error) {
      console.error('❌ Error handling job assignment:', error);
    }
  }

  /**
   * Handle driver available event
   */
  private handleDriverAvailable(driverData: any) {
    try {
      const currentState = store.getState();
      const currentDrivers = currentState.commonReducer.drivers || [];
      
      // Update driver availability
      const updatedDrivers = currentDrivers.map((driver: any) => {
        if (driver.id === driverData.id || driver._id === driverData.id) {
          return {
            ...driver,
            isAvailable: true,
            lastSeen: new Date().toISOString(),
          };
        }
        return driver;
      });
      
      // If driver not in list, add them
      const driverExists = currentDrivers.some((driver: any) => 
        driver.id === driverData.id || driver._id === driverData.id
      );
      
      if (!driverExists) {
        updatedDrivers.push({
          ...driverData,
          isAvailable: true,
          lastSeen: new Date().toISOString(),
        });
      }
      
      // Update Redux store
      store.dispatch(setDrivers(updatedDrivers));
      
      console.log('Driver availability updated:', driverData);
    } catch (error) {
      console.error('Error handling driver available:', error);
    }
  }

  /**
   * Handle driver unavailable event
   */
  private handleDriverUnavailable(driverData: any) {
    try {
      const currentState = store.getState();
      const currentDrivers = currentState.commonReducer.drivers || [];
      
      // Update driver availability
      const updatedDrivers = currentDrivers.map((driver: any) => {
        if (driver.id === driverData.id || driver._id === driverData.id) {
          return {
            ...driver,
            isAvailable: false,
            lastSeen: new Date().toISOString(),
          };
        }
        return driver;
      });
      
      // Update Redux store
      store.dispatch(setDrivers(updatedDrivers));
      
      console.log('Driver unavailability updated:', driverData);
    } catch (error) {
      console.error('Error handling driver unavailable:', error);
    }
  }

  /**
   * Handle new message event
   */
  private handleNewMessage(messageData: any) {
    try {
      console.log('💬 Processing new message:', messageData);
      
      if (!store) {
        console.error('❌ Store is not available');
        return;
      }

      // Convert API message format to local message format
      const newMessage = {
        id: (messageData.id || messageData._id || Date.now().toString()).toString(),
        conversationId: (messageData.conversationId || messageData.conversation_id || '').toString(),
        senderId: (messageData.senderId || messageData.sender_id || messageData.senderUserId || '').toString(),
        receiverId: (messageData.receiverId || messageData.receiver_id || messageData.receiverUserId || 'all').toString(),
        type: messageData.messageType || messageData.type || 'text',
        content: messageData.content || '',
        timestamp: messageData.sentAt || messageData.timestamp || messageData.createdAt || new Date().toISOString(),
        read: false,
        delivered: true,
        status: 'delivered',
        jobId: messageData.jobId || messageData.job_id,
        metadata: messageData.metadata || null,
      };

      console.log('💬 Converted message:', newMessage);

      // Import the chat store dynamically to avoid circular dependencies
      import('@app/store/chatStore').then(({ useChatStore }) => {
        const { sendMessage } = useChatStore.getState();
        
        // Add the message to the chat store
        sendMessage(newMessage.conversationId, newMessage);
        
        console.log('✅ New message added to chat store');
      }).catch((error) => {
        console.error('❌ Error importing chat store:', error);
      });

    } catch (error) {
      console.error('❌ Error handling new message:', error);
    }
  }

  /**
   * Handle online user list event
   */
  private handleOnlineUserList(data: any) {
    try {
      console.log('👥 Processing online user list:', data);
      
      if (!store) {
        console.error('❌ Store is not available');
        return;
      }

      // Import the chat store dynamically to avoid circular dependencies
      import('@app/store/chatStore').then(({ useChatStore }) => {
        const { setOnlineUsers } = useChatStore.getState();
        
        // Transform the API data to our OnlineUser format
        const transformedUsers = this.transformUsersData(data.users || data || []);
        
        // Set the online users list
        setOnlineUsers(transformedUsers);
        
        console.log('✅ Online users list updated in chat store:', transformedUsers);
      }).catch((error) => {
        console.error('❌ Error importing chat store:', error);
      });

    } catch (error) {
      console.error('❌ Error handling online user list:', error);
    }
  }

  /**
   * Handle online users updated event
   */
  private handleOnlineUsersUpdated(data: any) {
    try {
      console.log('👥 Processing online users updated:', data);
      
      if (!store) {
        console.error('❌ Store is not available');
        return;
      }

      // Import the chat store dynamically to avoid circular dependencies
      import('@app/store/chatStore').then(({ useChatStore }) => {
        const { updateOnlineUsers } = useChatStore.getState();
        
        // Transform the API data to our OnlineUser format
        const transformedUsers = this.transformUsersData(data.users || data || []);
        
        // Update the online users list
        updateOnlineUsers(transformedUsers);
        
        console.log('✅ Online users updated in chat store:', transformedUsers);
      }).catch((error) => {
        console.error('❌ Error importing chat store:', error);
      });

    } catch (error) {
      console.error('❌ Error handling online users updated:', error);
    }
  }

  /**
   * Transform API user data to our OnlineUser format
   */
  private transformUsersData(apiUsers: any[]): any[] {
    return apiUsers.map(user => ({
      id: user.userId?.toString() || user.id?.toString() || '',
      name: user.userName || `${user.firstName || ''} ${user.lastName || ''}`.trim() || 'Unknown User',
      avatar: user.profileImage || undefined,
      lastSeen: user.lastOnline || undefined,
      isOnline: user.isOnline || false,
      email: user.email || undefined,
    }));
  }

  /**
   * Emit job assignment
   */
  assignJob(jobId: string, driverId: string) {
    if (!this.socket || !this.isConnected) {
      console.error('Socket not connected');
      return false;
    }

    try {
      this.socket.emit('job:assign', {
        jobId,
        driverId,
        timestamp: new Date().toISOString(),
      });
      
      console.log('Job assignment emitted:', { jobId, driverId });
      return true;
    } catch (error) {
      console.error('Error emitting job assignment:', error);
      return false;
    }
  }

  /**
   * Emit driver status update
   */
  updateDriverStatus(driverId: string, isAvailable: boolean) {
    if (!this.socket || !this.isConnected) {
      console.error('Socket not connected');
      return false;
    }

    try {
      this.socket.emit('driver:status', {
        driverId,
        isAvailable,
        timestamp: new Date().toISOString(),
      });
      
      console.log('Driver status update emitted:', { driverId, isAvailable });
      return true;
    } catch (error) {
      console.error('Error emitting driver status:', error);
      return false;
    }
  }

  /**
   * Emit job creation event (for testing)
   */
  emitJobCreated(jobData: any) {
    if (!this.socket || !this.isConnected) {
      console.error('Socket not connected');
      return false;
    }

    try {
      this.socket.emit('job:created', {
        ...jobData,
        timestamp: new Date().toISOString(),
      });
      
      console.log('📤 Job created event emitted:', jobData);
      return true;
    } catch (error) {
      console.error('Error emitting job created:', error);
      return false;
    }
  }

  /**
   * Emit job assignment event (for testing)
   */
  emitJobAssigned(jobId: string, driverId: string, driverName?: string) {
    if (!this.socket || !this.isConnected) {
      console.error('Socket not connected');
      return false;
    }

    try {
      this.socket.emit('job:assign', {
        jobId,
        driverId,
        driverName,
        timestamp: new Date().toISOString(),
      });
      
      console.log('📤 Job assignment event emitted:', { jobId, driverId, driverName });
      return true;
    } catch (error) {
      console.error('Error emitting job assignment:', error);
      return false;
    }
  }

  /**
   * Join room for specific job
   */
  joinJobRoom(jobId: string) {
    if (!this.socket || !this.isConnected) {
      console.error('Socket not connected');
      return false;
    }

    try {
      this.socket.emit('join:job', { jobId });
      console.log('Joined job room:', jobId);
      return true;
    } catch (error) {
      console.error('Error joining job room:', error);
      return false;
    }
  }

  /**
   * Leave room for specific job
   */
  leaveJobRoom(jobId: string) {
    if (!this.socket || !this.isConnected) {
      console.error('Socket not connected');
      return false;
    }

    try {
      this.socket.emit('leave:job', { jobId });
      console.log('Left job room:', jobId);
      return true;
    } catch (error) {
      console.error('Error leaving job room:', error);
      return false;
    }
  }

  /**
   * Join room for specific conversation
   */
  joinConversationRoom(conversationId: string) {
    if (!this.socket || !this.isConnected) {
      console.error('Socket not connected');
      return false;
    }

    try {
      this.socket.emit('join:conversation', { conversationId });
      console.log('Joined conversation room:', conversationId);
      return true;
    } catch (error) {
      console.error('Error joining conversation room:', error);
      return false;
    }
  }

  /**
   * Leave room for specific conversation
   */
  leaveConversationRoom(conversationId: string) {
    if (!this.socket || !this.isConnected) {
      console.error('Socket not connected');
      return false;
    }

    try {
      this.socket.emit('leave:conversation', { conversationId });
      console.log('Left conversation room:', conversationId);
      return true;
    } catch (error) {
      console.error('Error leaving conversation room:', error);
      return false;
    }
  }

  /**
   * Emit new message
   */
  emitNewMessage(messageData: any) {
    if (!this.socket || !this.isConnected) {
      console.error('Socket not connected');
      return false;
    }

    try {
      this.socket.emit('send_message', messageData);
      console.log('📤 Message sent via socket:', messageData);
      return true;
    } catch (error) {
      console.error('Error emitting message:', error);
      return false;
    }
  }

  /**
   * Disconnect socket
   */
  disconnect() {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
      this.isConnected = false;
      console.log('Socket disconnected');
    }
  }

  /**
   * Get connection status
   */
  isSocketConnected(): boolean {
    return this.isConnected && this.socket?.connected === true;
  }

  /**
   * Get socket instance
   */
  getSocket(): Socket | null {
    return this.socket;
  }

  /**
   * Test job assignment (for debugging)
   */
  testJobAssignment(jobId: string, driverId: string, driverName: string) {
    console.log('🧪 Testing job assignment:', { jobId, driverId, driverName });
    const testData = {
      jobId,
      driverId,
      driverName,
      job: {
        id: jobId,
        title: 'Test Job Assignment'
      },
      driver: {
        id: driverId,
        name: driverName
      }
    };
    this.handleJobAssigned(testData);
  }


  /**
   * Get detailed connection info
   */
  getConnectionInfo() {
    if (!this.socket) {
      return {
        connected: false,
        id: null,
        transport: null,
        url: null,
        error: 'No socket instance'
      };
    }

    return {
      connected: this.socket.connected,
      id: this.socket.id,
      transport: this.socket.io.engine.transport.name,
      url: 'Connected',
      error: null
    };
  }

  /**
   * Log connection status
   */
  logConnectionStatus() {
    const info = this.getConnectionInfo();
    console.log('=== Socket Connection Status ===');
    console.log('Connected:', info.connected);
    console.log('Socket ID:', info.id);
    console.log('Transport:', info.transport);
    console.log('URL:', info.url);
    console.log('Error:', info.error);
    console.log('================================');
  }


}

// Export singleton instance
export const socketService = new SocketService();
export default socketService;
