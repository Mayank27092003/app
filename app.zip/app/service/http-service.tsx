/**
 * Axios API
 * Middleware of api request and response
 * @format
 */

import * as Config from "@app/configs";
import { AuthToken } from "@app/helpers";
import axios, { AxiosError } from "axios";

/**
 * Creating custom instance for config
 * server configurations.
 * baseUrl, timeout, api-token etc.
 */

const httpRequest = axios.create({
  baseURL: Config.BASE_URL,
  timeout: Config.API_TIMEOUT || 3500,
  headers: {
    "Content-Type": "application/json",
  },
});
/**
 * axios request interceptors for debugging
 * and modify request data
 */

httpRequest.interceptors.request.use(
  async (reqConfig) => {
    const token = await AuthToken.get();

    if (token) reqConfig.headers.Authorization = `Bearer ${token}`;
console.log("httpRequesthttpRequest", reqConfig ,token);

    return reqConfig;
  },
  (error) => {
    return Promise.reject(error);
  }
);

/**
 * Customizing axios success and error
 * data to easily handle them in app
 */
httpRequest.interceptors.response.use(
  (response) => {
    if (__DEV__) {
      console.log("response", response.data);
    }
    return response.data;
  },
  async (error) => {
    // Check if it's a Google token refresh error
    if (
      console.log("errorccccc", error),
      
      error?.response?.data?.error?.status === "UNAUTHENTICATED" 
    ) {
      // Import the new Google token service
      // const { refreshGoogleTokenIfNeeded } = await import(
      //   "./google-token-service"
      // );
      // const googleAuth = await getGoogleAuth();
      // console.log("googleAuth", googleAuth);
      // if (googleAuth) {
      //   try {
      //     // await refreshGoogleTokenIfNeeded(googleAuth);
      //     // Retry the original request with the new token
      //     return httpRequest.request(error.config);
      //   } catch (refreshError) {
      //     console.error("Failed to refresh Google token:", refreshError);
      //     // If refresh fails, reject with the original error
      //     return Promise.reject(handleApiError(error));
      //   }
      // }
    }
    return Promise.reject(handleApiError(error));
  }
);

/**
 * Handling error
 * @param {*} error
 * @returns
 */
const handleApiError = (error: AxiosError | any) => {
  if (__DEV__) {
    console.error("error in api", error?.response || error?.message || error);
  }

  if (error?.response?.data) {
    return {
      message:
        error?.response?.data?.message ||
        "Something went wrong. Please try again.",
      status: error?.response?.status || null,
    };
  } else if (error?.request) {
    return {
      message: "No response from server. Check your internet or server.",
    };
  } else {
    return {
      message: error?.message || "Unknown error occurred.",
    };
  }
};

export { httpRequest };
