/**
 * Image source
 * All static images should be import here
 * @format
 */

const Images = {
  SplashIcon: require('./../assets/icons/splash-icon.png'),
 dummyImage: require('./../assets/dummyImage.png'),

  //Images

};

export { Images };
