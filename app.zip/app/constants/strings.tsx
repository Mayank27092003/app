/**
 * App string constant
 * All static text should be import here
 * @format
 */
const strings = {};

export { strings };
