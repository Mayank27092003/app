/**
 * Typography
 * @format
 */

export const fonts = {
  Nunito_700Bold: 'Nunito_700Bold',
  Nunito_400Regular: 'Nunito_400Regular',
  Poppins_500Medium: 'Poppins_500Medium',
  Nunito_400Regular_Italic: 'Nunito_400Regular_Italic',
};
