/**
 * Debug Module
 * @format
 */

export { default as SocketDebugScreen } from './view/socketDebug';
