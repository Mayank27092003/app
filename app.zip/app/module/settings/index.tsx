/**
 * @format
 * Setting Module
 */

import { LanguageSettingsScreen } from './view/language';
import { TermsScreen } from './view/terms';

export { LanguageSettingsScreen,TermsScreen };
