/**
 * @format
 * Verification Module
 */

import { VerificationCameraScreen } from './view/camera';

export { VerificationCameraScreen };
