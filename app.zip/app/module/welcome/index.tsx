/**
 * @format
 * Welcome Module
 */

import { WelcomeScreen } from './view/welcome';
import {AppIntro} from './view/appIntro';

export { WelcomeScreen,AppIntro };
