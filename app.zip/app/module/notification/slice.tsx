/**
 * Notification slice
 * @format
 */

import { createAction } from '@reduxjs/toolkit';

export const notification = createAction<{}>('NOTIFICATION/NOTIFICATIONS');

