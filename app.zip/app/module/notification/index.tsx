/**
 * @format
 * Message Module
 */

import { NotificationsScreen } from './view/notifications';

export { NotificationsScreen };
