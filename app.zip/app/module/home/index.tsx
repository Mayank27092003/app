/**
 * Home Module  
 */

import { HomeScreen } from './view/home-screen';

export { HomeScreen };