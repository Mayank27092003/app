import React, { useEffect, useState, useRef } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Dimensions,
} from "react-native";
import MapView, { Marker, Polyline } from "react-native-maps";
import { useRoute, useNavigation } from "@react-navigation/native";
import {
  CheckCircle,
  AlertCircle,
  ZoomIn,
  ZoomOut,
  Locate,
  Route,
  Play,
  Pause,
  Square,
  Truck,
  Package,
  Home,
  ArrowLeft,
} from "lucide-react-native";

// Screens
import { Colors, useThemedStyle } from "@app/styles";
import { useAuthStore } from "@app/store/authStore";
import { useJobStore } from "@app/store/jobStore";
import { useLocationStore } from "@app/store/locationStore";
import { Job } from "@app/types";
import { Button } from "@app/components/Button";
import { getStyles } from "./tripTrackingStyles";

const { width, height } = Dimensions.get('window');

interface TripMilestone {
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'in_progress' | 'completed';
  timestamp?: string;
  location?: {
    latitude: number;
    longitude: number;
  };
}

function TripTrackingScreen() {
  const styles = useThemedStyle(getStyles);
  const route = useRoute();
  const navigation = useNavigation();
  const { userRole, userProfile } = useAuthStore();
  const { jobs } = useJobStore();
  const {
    currentLocation,
    locationPermission,
    requestLocationPermission,
    startLocationTracking,
  } = useLocationStore();

  // Get job data from navigation params
  const { job: passedJob } = route.params as { job?: Job; jobId?: string };

  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [tripStarted, setTripStarted] = useState(false);
  const [tripPaused, setTripPaused] = useState(false);
  const [currentMilestone, setCurrentMilestone] = useState(0);
  const [tripStartTime, setTripStartTime] = useState<Date | null>(null);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [mapRegion, setMapRegion] = useState({
    latitude: 40.7589,
    longitude: -73.9851,
    latitudeDelta: 0.0922,
    longitudeDelta: 0.0421,
  });
  const [distanceToPickup, setDistanceToPickup] = useState<number | null>(null);
  const [distanceToDelivery, setDistanceToDelivery] = useState<number | null>(null);
  const [etaToPickup, setEtaToPickup] = useState<string | null>(null);
  const [etaToDelivery, setEtaToDelivery] = useState<string | null>(null);
  
  const mapRef = useRef<MapView>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Trip milestones based on job status
  const tripMilestones: TripMilestone[] = [
    {
      id: 'start',
      title: 'Trip Started',
      description: 'Begin your delivery trip',
      status: 'pending',
    },
    {
      id: 'enroute_pickup',
      title: 'En Route to Pickup',
      description: 'Heading to pickup location',
      status: 'pending',
    },
    {
      id: 'arrived_pickup',
      title: 'Arrived at Pickup',
      description: 'Reached pickup location',
      status: 'pending',
    },
    {
      id: 'loaded',
      title: 'Cargo Loaded',
      description: 'Cargo has been loaded',
      status: 'pending',
    },
    {
      id: 'enroute_delivery',
      title: 'En Route to Delivery',
      description: 'Heading to delivery location',
      status: 'pending',
    },
    {
      id: 'arrived_delivery',
      title: 'Arrived at Delivery',
      description: 'Reached delivery location',
      status: 'pending',
    },
    {
      id: 'delivered',
      title: 'Cargo Delivered',
      description: 'Cargo has been delivered',
      status: 'pending',
    },
  ];

  // Utility function to calculate distance between two coordinates
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371; // Radius of the Earth in kilometers
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c; // Distance in kilometers
  };

  // Utility function to calculate ETA based on distance and average speed
  const calculateETA = (distance: number, averageSpeed: number = 30): string => {
    const timeInHours = distance / averageSpeed;
    const hours = Math.floor(timeInHours);
    const minutes = Math.round((timeInHours - hours) * 60);
    
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    }
    return `${minutes}m`;
  };

  // Update map region to fit all markers
  const fitMapToMarkers = () => {
    if (!mapRef.current) return;

    // Use dummy data if no job is selected
    const jobToUse = selectedJob || {
      pickupLocation: { lat: 40.7505, lng: -73.9934 },
      dropoffLocation: { lat: 40.7282, lng: -73.9942 }
    };

    const locationToUse = currentLocation || {
      latitude: 40.7589,
      longitude: -73.9851,
    };

    const coordinates = [
      {
        latitude: locationToUse.latitude,
        longitude: locationToUse.longitude,
      },
      {
        latitude: jobToUse.pickupLocation.lat,
        longitude: jobToUse.pickupLocation.lng,
      },
      {
        latitude: jobToUse.dropoffLocation.lat,
        longitude: jobToUse.dropoffLocation.lng,
      },
    ].filter(coord => coord.latitude !== 0 && coord.longitude !== 0);

    if (coordinates.length === 0) return;

    mapRef.current.fitToCoordinates(coordinates, {
      edgePadding: { top: 100, right: 100, bottom: 100, left: 100 },
      animated: true,
    });
  };

  // Get active jobs for the current user
  const activeJobs = jobs.filter((job) => {
    if (userRole === "driver") {
      return (
        job.assignedDriverId === userProfile?.id &&
        [
          "assigned",
          "in_progress",
          "arrived_pickup",
          "loaded",
          "in_transit",
          "arrived_delivery",
        ].includes(job.status)
      );
    } else {
      return (
        job.merchantId === userProfile?.id &&
        [
          "assigned",
          "in_progress",
          "arrived_pickup",
          "loaded",
          "in_transit",
          "arrived_delivery",
        ].includes(job.status)
      );
    }
  });

  // Mock data for UI demonstration
  const mockActiveJobs: Job[] = [
    {
      id: "mock-1",
      title: "Deliver Electronics to Downtown",
      description: "Transport electronic equipment from warehouse to downtown office",
      status: "in_progress",
      payAmount: "150.00",
      currency: "USD",
      assignedDriverId: userProfile?.id || "driver-1",
      merchantId: "merchant-1",
      merchantName: "Tech Solutions Inc.",
      merchantRating: 4.5,
      compensation: 150.00,
      distance: 5.2,
      estimatedDuration: "2 hours",
      cargoType: "Electronics",
      cargoWeight: "150 kg",
      pickupLocation: {
        address: "123 Warehouse St",
        city: "New York",
        state: "NY",
        zipCode: "10001",
        country: "US",
        lat: 40.7589,
        lng: -73.9851,
        date: "2024-01-15",
        time: "09:00"
      },
      dropoffLocation: {
        address: "456 Business Ave",
        city: "New York", 
        state: "NY",
        zipCode: "10002",
        country: "US",
        lat: 40.7505,
        lng: -73.9934,
        date: "2024-01-15",
        time: "11:00"
      },
      requiredTruckType: "Box Truck",
      specialRequirements: "Handle with care - fragile electronics",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
  ];

  // Use mock data if no real active jobs
  const displayJobs = activeJobs.length > 0 ? activeJobs : mockActiveJobs;

  // Timer effect for elapsed time
  useEffect(() => {
    if (tripStarted && !tripPaused && tripStartTime) {
      timerRef.current = setInterval(() => {
        setElapsedTime(Math.floor((Date.now() - tripStartTime.getTime()) / 1000));
      }, 1000);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [tripStarted, tripPaused, tripStartTime]);

  // Update distances and ETAs when location or selected job changes
  useEffect(() => {
    const jobToUse = selectedJob || {
      pickupLocation: { lat: 40.7505, lng: -73.9934 },
      dropoffLocation: { lat: 40.7282, lng: -73.9942 }
    };

    const locationToUse = currentLocation || {
      latitude: 40.7589,
      longitude: -73.9851,
      timestamp: Date.now()
    };

    const pickupDistance = calculateDistance(
      locationToUse.latitude,
      locationToUse.longitude,
      jobToUse.pickupLocation.lat,
      jobToUse.pickupLocation.lng
    );
    
    const deliveryDistance = calculateDistance(
      locationToUse.latitude,
      locationToUse.longitude,
      jobToUse.dropoffLocation.lat,
      jobToUse.dropoffLocation.lng
    );

    setDistanceToPickup(pickupDistance);
    setDistanceToDelivery(deliveryDistance);
    setEtaToPickup(calculateETA(pickupDistance));
    setEtaToDelivery(calculateETA(deliveryDistance));

    setMapRegion({
      latitude: locationToUse.latitude,
      longitude: locationToUse.longitude,
      latitudeDelta: 0.0922,
      longitudeDelta: 0.0421,
    });
  }, [currentLocation, selectedJob]);

  // Fit map to markers when job changes
  useEffect(() => {
    setTimeout(() => {
      fitMapToMarkers();
    }, 1000);
  }, [selectedJob]);

  // Initialize with passed job or first available job
  useEffect(() => {
    if (passedJob) {
      setSelectedJob(passedJob);
    } else if (displayJobs.length > 0 && !selectedJob) {
      setSelectedJob(displayJobs[0]);
    }
  }, [passedJob, displayJobs, selectedJob]);

  const handleStartTrip = () => {
    setTripStarted(true);
    setTripStartTime(new Date());
    setCurrentMilestone(0);
    startLocationTracking();
  };

  const handlePauseTrip = () => {
    setTripPaused(!tripPaused);
  };

  const handleStopTrip = () => {
    setTripStarted(false);
    setTripPaused(false);
    setTripStartTime(null);
    setElapsedTime(0);
    setCurrentMilestone(0);
  };

  const handleNextMilestone = () => {
    if (currentMilestone < tripMilestones.length - 1) {
      setCurrentMilestone(currentMilestone + 1);
    }
  };

  const formatTime = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
      return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const renderMapView = () => {
    const jobToUse = selectedJob || {
      pickupLocation: { 
        lat: 40.7505, 
        lng: -73.9934,
        address: "456 Business Ave, New York, NY 10002"
      },
      dropoffLocation: { 
        lat: 40.7282, 
        lng: -73.9942,
        address: "321 Corporate Plaza, Manhattan, NY 10003"
      }
    };

    // Get current location or use default
    const driverLocation = currentLocation || {
      latitude: 40.7589,
      longitude: -73.9851
    };

    // Create coordinates array with proper order for route
    const coordinates = [
      {
        latitude: driverLocation.latitude,
        longitude: driverLocation.longitude,
        title: "Your Location",
        description: currentLocation ? "Current driver location" : "Default location",
        type: "driver"
      },
      {
        latitude: jobToUse.pickupLocation.lat,
        longitude: jobToUse.pickupLocation.lng,
        title: "Pickup Location",
        description: jobToUse.pickupLocation.address,
        type: "pickup"
      },
      {
        latitude: jobToUse.dropoffLocation.lat,
        longitude: jobToUse.dropoffLocation.lng,
        title: "Delivery Location",
        description: jobToUse.dropoffLocation.address,
        type: "delivery"
      },
    ].filter(coord => coord.latitude !== 0 && coord.longitude !== 0);

    // Create route coordinates for polyline (driver -> pickup -> delivery)
    const routeCoordinates = [
      { latitude: driverLocation.latitude, longitude: driverLocation.longitude },
      { latitude: jobToUse.pickupLocation.lat, longitude: jobToUse.pickupLocation.lng },
      { latitude: jobToUse.dropoffLocation.lat, longitude: jobToUse.dropoffLocation.lng }
    ];

    return (
      <View style={styles.mapViewContainer}>
        <MapView
          ref={mapRef}
          style={styles.map}
          region={mapRegion}
          provider='google'
          onRegionChangeComplete={setMapRegion}
          showsUserLocation={true}
          showsMyLocationButton={false}
          showsCompass={true}
          showsScale={true}
          mapType='standard'
          initialRegion={mapRegion}
          onMapReady={() => {
            console.log("Trip tracking map is ready!");
            setTimeout(() => {
              fitMapToMarkers();
            }, 1000);
          }}
        >
          {coordinates.map((coord, index) => {
            const getPinColor = () => {
              if (coord.type === 'driver') return '#00FF00';
              if (coord.type === 'pickup') return '#FF6B35';
              return '#4ECDC4';
            };

            const pinColor = getPinColor();
            return (
              <Marker
                key={`${coord.type}-${index}`}
                coordinate={{
                  latitude: coord.latitude,
                  longitude: coord.longitude,
                }}
                title={coord.title}
                description={coord.description}
                pinColor={pinColor}
              />
            );
          })}
          
          {/* Route polyline - Driver to Pickup to Delivery */}
          {routeCoordinates.length >= 2 && (
            <Polyline
              coordinates={routeCoordinates}
              strokeColor="#007AFF"
              strokeWidth={4}
              lineDashPattern={[8, 4]}
            />
          )}
          
          {/* Additional route segments for better visualization */}
          {routeCoordinates.length >= 3 && (
            <>
              {/* Driver to Pickup segment */}
              <Polyline
                coordinates={[routeCoordinates[0], routeCoordinates[1]]}
                strokeColor="#FF6B35"
                strokeWidth={3}
                lineDashPattern={[5, 5]}
              />
              {/* Pickup to Delivery segment */}
              <Polyline
                coordinates={[routeCoordinates[1], routeCoordinates[2]]}
                strokeColor="#4ECDC4"
                strokeWidth={3}
                lineDashPattern={[5, 5]}
              />
            </>
          )}
        </MapView>

        {/* Back Button */}
        <View style={styles.backButtonContainer}>
          <TouchableOpacity 
            style={styles.backButton} 
            onPress={() => navigation.goBack()}
          >
            <ArrowLeft size={20} color={Colors.white} />
          </TouchableOpacity>
        </View>

        {/* Map Controls */}
        <View style={styles.mapControls}>
          <TouchableOpacity style={styles.mapControlButton} onPress={() => {
            if (mapRef.current) {
              mapRef.current.animateToRegion({
                ...mapRegion,
                latitudeDelta: mapRegion.latitudeDelta * 0.5,
                longitudeDelta: mapRegion.longitudeDelta * 0.5,
              });
            }
          }}>
            <ZoomIn size={20} color={Colors.white} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.mapControlButton} onPress={() => {
            if (mapRef.current) {
              mapRef.current.animateToRegion({
                ...mapRegion,
                latitudeDelta: mapRegion.latitudeDelta * 2,
                longitudeDelta: mapRegion.longitudeDelta * 2,
              });
            }
          }}>
            <ZoomOut size={20} color={Colors.white} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.mapControlButton} onPress={() => {
            if (currentLocation && mapRef.current) {
              mapRef.current.animateToRegion({
                latitude: currentLocation.latitude,
                longitude: currentLocation.longitude,
                latitudeDelta: 0.01,
                longitudeDelta: 0.01,
              });
            }
          }}>
            <Locate size={20} color={Colors.white} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.mapControlButton} onPress={fitMapToMarkers}>
            <Route size={20} color={Colors.white} />
          </TouchableOpacity>
        </View>

        {/* Trip Status Overlay */}
        <View style={styles.tripStatusOverlay}>
          <View style={styles.tripStatusHeader}>
            <Truck size={20} color={Colors.primary} />
            <Text style={styles.tripStatusTitle}>Trip Status</Text>
          </View>
          <Text style={styles.tripStatusText}>
            {(() => {
              if (tripStarted) {
                return tripPaused ? 'Paused' : 'In Progress';
              }
              return 'Not Started';
            })()}
          </Text>
          {tripStarted && (
            <Text style={styles.tripTimeText}>
              {formatTime(elapsedTime)}
            </Text>
          )}
        </View>

        {/* Route Information Overlay */}
        {/* <View style={styles.routeInfoOverlay}>
          <Text style={styles.routeInfoTitle}>Trip Route</Text>
          <View style={styles.routeInfoItem}>
            <View style={[styles.routeInfoDot, { backgroundColor: '#00FF00' }]} />
            <Text style={styles.routeInfoText}>Driver Location</Text>
          </View>
          <View style={styles.routeInfoItem}>
            <View style={[styles.routeInfoDot, { backgroundColor: '#FF6B35' }]} />
            <Text style={styles.routeInfoText}>Pickup Location</Text>
          </View>
          <View style={styles.routeInfoItem}>
            <View style={[styles.routeInfoDot, { backgroundColor: '#4ECDC4' }]} />
            <Text style={styles.routeInfoText}>Delivery Location</Text>
          </View>
        </View> */}
      </View>
    );
  };

  const renderTripControls = () => (
    <View style={styles.tripControlsContainer}>
      <View style={styles.tripControlsHeader}>
        <Text style={styles.tripControlsTitle}>Trip Controls</Text>
        {tripStarted && (
          <Text style={styles.tripTimeText}>
            {formatTime(elapsedTime)}
          </Text>
        )}
      </View>
      
      <View style={styles.tripControlsButtons}>
        {!tripStarted ? (
          <TouchableOpacity style={styles.startButton} onPress={handleStartTrip}>
            <Play size={20} color={Colors.white} />
            <Text style={styles.startButtonText}>Start Trip</Text>
          </TouchableOpacity>
        ) : (
          <>
            <TouchableOpacity 
              style={[styles.controlButton, tripPaused ? styles.resumeButton : styles.pauseButton]} 
              onPress={handlePauseTrip}
            >
              {tripPaused ? <Play size={20} color={Colors.white} /> : <Pause size={20} color={Colors.white} />}
              <Text style={styles.controlButtonText}>
                {tripPaused ? 'Resume' : 'Pause'}
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.controlButton} onPress={handleNextMilestone}>
              <CheckCircle size={20} color={Colors.white} />
              <Text style={styles.controlButtonText}>Next Step</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={[styles.controlButton, styles.stopButton]} onPress={handleStopTrip}>
              <Square size={20} color={Colors.white} />
              <Text style={styles.controlButtonText}>Stop</Text>
            </TouchableOpacity>
          </>
        )}
      </View>
    </View>
  );

  const renderTripMilestones = () => (
    <View style={styles.milestonesContainer}>
      <Text style={styles.milestonesTitle}>Trip Progress</Text>
      <ScrollView style={styles.milestonesScrollView} showsVerticalScrollIndicator={false}>
        {tripMilestones.map((milestone, index) => (
          <View key={milestone.id} style={styles.milestoneItem}>
            <View style={[
              styles.milestoneIcon,
              index < currentMilestone && styles.milestoneIconCompleted,
              index === currentMilestone && styles.milestoneIconActive,
            ]}>
              {index < currentMilestone ? (
                <CheckCircle size={16} color={Colors.white} />
              ) : (
                <Text style={styles.milestoneNumber}>{index + 1}</Text>
              )}
            </View>
            <View style={styles.milestoneContent}>
              <Text style={[
                styles.milestoneTitle,
                index < currentMilestone && styles.milestoneTitleCompleted,
                index === currentMilestone && styles.milestoneTitleActive,
              ]}>
                {milestone.title}
              </Text>
              <Text style={styles.milestoneDescription}>
                {milestone.description}
              </Text>
            </View>
          </View>
        ))}
      </ScrollView>
    </View>
  );

  const renderDistanceInfo = () => (
    <View style={styles.distanceInfoContainer}>
      <View style={styles.distanceInfoItem}>
        <Package size={20} color={Colors.primary} />
        <View style={styles.distanceInfoContent}>
          <Text style={styles.distanceInfoLabel}>To Pickup</Text>
          <Text style={styles.distanceInfoValue}>
            {distanceToPickup ? `${distanceToPickup.toFixed(1)} km` : '--'}
          </Text>
          <Text style={styles.distanceInfoEta}>
            ETA: {etaToPickup || '--'}
          </Text>
        </View>
      </View>
      
      <View style={styles.distanceInfoItem}>
        <Home size={20} color={Colors.secondary} />
        <View style={styles.distanceInfoContent}>
          <Text style={styles.distanceInfoLabel}>To Delivery</Text>
          <Text style={styles.distanceInfoValue}>
            {distanceToDelivery ? `${distanceToDelivery.toFixed(1)} km` : '--'}
          </Text>
          <Text style={styles.distanceInfoEta}>
            ETA: {etaToDelivery || '--'}
          </Text>
        </View>
      </View>
    </View>
  );

  if (!locationPermission) {
    return (
      <View style={styles.permissionContainer}>
        <AlertCircle size={40} color={Colors.warning} style={styles.permissionIcon} />
        <Text style={styles.permissionTitle}>
          Location Permission Required
        </Text>
        <Text style={styles.permissionText}>
          Please enable location access to track your trip
        </Text>
        <Button
          title="Enable Location"
          variant="primary"
          onPress={requestLocationPermission}
          style={styles.permissionButton}
        />
      </View>
    );
  }

  if (displayJobs.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Truck size={40} color={Colors.gray400} style={styles.emptyIcon} />
        <Text style={styles.emptyTitle}>No Active Trips</Text>
        <Text style={styles.emptyText}>
          You don't have any active trips to track
        </Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Mock data indicator */}
      {activeJobs.length === 0 && displayJobs.length > 0 && (
        <View style={styles.mockDataIndicator}>
          <Text style={styles.mockDataText}>📱 Demo Mode - Showing Sample Trip</Text>
        </View>
      )}
      
      <View style={styles.mainContent}>
        {renderMapView()}
        {renderTripControls()}
        {renderDistanceInfo()}
        {renderTripMilestones()}
      </View>
    </View>
  );
}

export { TripTrackingScreen };
