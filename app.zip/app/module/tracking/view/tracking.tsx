import React, { useEffect, useState, useRef } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Alert,
  Platform,
} from "react-native";
import MapView, { Marker, Polyline ,PROVIDER_GOOGLE} from "react-native-maps";
import {
  MapPin,
  Navigation,
  Clock,
  CheckCircle,
  AlertCircle,
  Camera,
  MessageCircle,
  Phone,
  ZoomIn,
  ZoomOut,
  Locate,
  Route,
  Truck,
} from "lucide-react-native";
import { useNavigation } from "@react-navigation/native";
import { useTranslation } from "react-i18next";

// Screens
import { Colors, useThemedStyle } from "@app/styles";
import { useAuthStore } from "@app/store/authStore";
import { useJobStore } from "@app/store/jobStore";
import { useLocationStore } from "@app/store/locationStore";
import { useChatStore } from "@app/store/chatStore";
import { Job } from "@app/types";
import { Button } from "@app/components/Button";
import { getStyles } from "./styles";
import { Routes } from "../../../navigator";

function TrackingScreen() {
  const { t } = useTranslation();
  const styles = useThemedStyle(getStyles);
  const navigation = useNavigation();
  const { userRole, userProfile } = useAuthStore();
  const { jobs, updateJobStatus } = useJobStore();
  const {
    currentLocation,
    locationPermission,
    requestLocationPermission,
    startLocationTracking,
    isTracking,
  } = useLocationStore();
  const { getOrCreateConversation, initiateCall } = useChatStore();

  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [updatingStatus, setUpdatingStatus] = useState(false);
  const [mapView, setMapView] = useState<'map' | 'list'>('map');
  const [mapRegion, setMapRegion] = useState({
    latitude: 40.7589,
    longitude: -73.9851,
    latitudeDelta: 0.0922,
    longitudeDelta: 0.0421,
  });
  const [mapReady, setMapReady] = useState(false);
  const [distanceToPickup, setDistanceToPickup] = useState<number | null>(null);
  const [distanceToDelivery, setDistanceToDelivery] = useState<number | null>(null);
  const [etaToPickup, setEtaToPickup] = useState<string | null>(null);
  const [etaToDelivery, setEtaToDelivery] = useState<string | null>(null);
  
  const mapRef = useRef<MapView>(null);

  // Utility function to calculate distance between two coordinates
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371; // Radius of the Earth in kilometers
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c; // Distance in kilometers
  };

  // Utility function to calculate ETA based on distance and average speed
  const calculateETA = (distance: number, averageSpeed: number = 30): string => {
    const timeInHours = distance / averageSpeed;
    const hours = Math.floor(timeInHours);
    const minutes = Math.round((timeInHours - hours) * 60);
    
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    }
    return `${minutes}m`;
  };

  // Update map region to fit all markers
  const fitMapToMarkers = () => {
    if (!mapRef.current) return;

    // Use dummy data if no job is selected
    const jobToUse = selectedJob || {
      pickupLocation: { lat: 40.7505, lng: -73.9934 },
      dropoffLocation: { lat: 40.7282, lng: -73.9942 }
    };

    const locationToUse = currentLocation || {
      latitude: 40.7589,
      longitude: -73.9851,
    };

    const coordinates = [
      {
        latitude: locationToUse.latitude,
        longitude: locationToUse.longitude,
      },
      {
        latitude: jobToUse.pickupLocation.lat,
        longitude: jobToUse.pickupLocation.lng,
      },
      {
        latitude: jobToUse.dropoffLocation.lat,
        longitude: jobToUse.dropoffLocation.lng,
      },
    ].filter(coord => coord.latitude !== 0 && coord.longitude !== 0);

    if (coordinates.length === 0) return;

    mapRef.current.fitToCoordinates(coordinates, {
      edgePadding: { top: 50, right: 50, bottom: 50, left: 50 },
      animated: true,
    });
  };

  // Get active jobs for the current user
  const activeJobs = jobs.filter((job) => {
    if (userRole === "driver") {
      return (
        job.assignedDriverId === userProfile?.id &&
        [
          "assigned",
          "in_progress",
          "arrived_pickup",
          "loaded",
          "in_transit",
          "arrived_delivery",
        ].includes(job.status)
      );
    } else {
      return (
        job.merchantId === userProfile?.id &&
        [
          "assigned",
          "in_progress",
          "arrived_pickup",
          "loaded",
          "in_transit",
          "arrived_delivery",
        ].includes(job.status)
      );
    }
  });

  // Mock data for UI demonstration - remove this in production
  const mockActiveJobs: Job[] = [
    {
      id: "mock-1",
      title: "Deliver Electronics to Downtown",
      description: "Transport electronic equipment from warehouse to downtown office",
      status: "in_progress",
      payAmount: "150.00",
      currency: "USD",
      assignedDriverId: userProfile?.id || "driver-1",
      merchantId: "merchant-1",
      merchantName: "Tech Solutions Inc.",
      merchantRating: 4.5,
      compensation: 150.00,
      distance: 5.2,
      estimatedDuration: "2 hours",
      cargoType: "Electronics",
      cargoWeight: "150 kg",
      pickupLocation: {
        address: "123 Warehouse St",
        city: "New York",
        state: "NY",
        zipCode: "10001",
        country: "US",
        lat: 40.7589,
        lng: -73.9851,
        date: "2024-01-15",
        time: "09:00"
      },
      dropoffLocation: {
        address: "456 Business Ave",
        city: "New York", 
        state: "NY",
        zipCode: "10002",
        country: "US",
        lat: 40.7505,
        lng: -73.9934,
        date: "2024-01-15",
        time: "11:00"
      },
      requiredTruckType: "Box Truck",
      specialRequirements: "Handle with care - fragile electronics",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: "mock-2", 
      title: "Furniture Delivery",
      description: "Deliver office furniture to new building",
      status: "assigned",
      payAmount: "200.00",
      currency: "USD",
      assignedDriverId: userProfile?.id || "driver-1",
      merchantId: "merchant-2",
      merchantName: "Office Supply Co.",
      merchantRating: 4.2,
      compensation: 200.00,
      distance: 8.7,
      estimatedDuration: "3 hours",
      cargoType: "Furniture",
      cargoWeight: "300 kg",
      pickupLocation: {
        address: "789 Furniture Blvd",
        city: "Brooklyn",
        state: "NY", 
        zipCode: "11201",
        country: "US",
        lat: 40.6892,
        lng: -73.9442,
        date: "2024-01-16",
        time: "10:00"
      },
      dropoffLocation: {
        address: "321 Corporate Plaza",
        city: "Manhattan",
        state: "NY",
        zipCode: "10003", 
        country: "US",
        lat: 40.7282,
        lng: -73.9942,
        date: "2024-01-16",
        time: "14:00"
      },
      requiredTruckType: "Flatbed",
      specialRequirements: "Use furniture blankets",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
  ];

  // Use mock data if no real active jobs (for UI demonstration)
  const displayJobs = activeJobs.length > 0 ? activeJobs : mockActiveJobs;

  useEffect(() => {
    if (displayJobs.length > 0 && !selectedJob) {
      setSelectedJob(displayJobs[0]);
    }

    if (locationPermission && selectedJob && userRole === "driver") {
      startLocationTracking();
    }
  }, [displayJobs, locationPermission, selectedJob]);

  // Update distances and ETAs when location or selected job changes
  useEffect(() => {
    // Use dummy data if no job is selected
    const jobToUse = selectedJob || {
      pickupLocation: { lat: 40.7505, lng: -73.9934 },
      dropoffLocation: { lat: 40.7282, lng: -73.9942 }
    };

    const locationToUse = currentLocation || {
      latitude: 40.7589,
      longitude: -73.9851,
      timestamp: Date.now()
    };

    const pickupDistance = calculateDistance(
      locationToUse.latitude,
      locationToUse.longitude,
      jobToUse.pickupLocation.lat,
      jobToUse.pickupLocation.lng
    );
    
    const deliveryDistance = calculateDistance(
      locationToUse.latitude,
      locationToUse.longitude,
      jobToUse.dropoffLocation.lat,
      jobToUse.dropoffLocation.lng
    );

    setDistanceToPickup(pickupDistance);
    setDistanceToDelivery(deliveryDistance);
    setEtaToPickup(calculateETA(pickupDistance));
    setEtaToDelivery(calculateETA(deliveryDistance));

    // Update map region to include current location
    const newRegion = {
      latitude: locationToUse.latitude,
      longitude: locationToUse.longitude,
      latitudeDelta: 0.0922,
      longitudeDelta: 0.0421,
    };
    
    console.log("Setting map region:", newRegion);
    setMapRegion(newRegion);
  }, [currentLocation, selectedJob]);

  // Fit map to markers when job changes
  useEffect(() => {
    if (mapView === 'map') {
      setTimeout(() => {
        fitMapToMarkers();
      }, 1000);
    }
  }, [selectedJob, mapView]);

  const handleRequestPermission = async () => {
    await requestLocationPermission();
  };


  const handleZoomIn = () => {
    if (mapRef.current) {
      mapRef.current.animateToRegion({
        ...mapRegion,
        latitudeDelta: mapRegion.latitudeDelta * 0.5,
        longitudeDelta: mapRegion.longitudeDelta * 0.5,
      });
    }
  };

  const handleZoomOut = () => {
    if (mapRef.current) {
      mapRef.current.animateToRegion({
        ...mapRegion,
        latitudeDelta: mapRegion.latitudeDelta * 2,
        longitudeDelta: mapRegion.longitudeDelta * 2,
      });
    }
  };

  const handleLocateMe = () => {
    if (currentLocation && mapRef.current) {
      mapRef.current.animateToRegion({
        latitude: currentLocation.latitude,
        longitude: currentLocation.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      });
    }
  };

  const handleFitToMarkers = () => {
    fitMapToMarkers();
  };

  const handleUpdateStatus = async (newStatus: Job["status"]) => {
    if (!selectedJob) return;

    // For certain status transitions, require verification
    if (
      (selectedJob.status === "assigned" && newStatus === "in_progress") ||
      (selectedJob.status === "arrived_delivery" && newStatus === "delivered")
    ) {
      const verificationType =
        selectedJob.status === "assigned" ? "start" : "finish";

      (navigation as any).navigate(Routes.VerificationCameraScreen, {
        jobId: selectedJob.id,
        type: verificationType,
      });
      return;
    }

    setUpdatingStatus(true);

    try {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      updateJobStatus(selectedJob.id, newStatus);
      setSelectedJob({
        ...selectedJob,
        status: newStatus,
      });
    } catch (error) {
      console.error("Error updating job status:", error);
      Alert.alert(t("errors.general"), t("jobs.statusUpdateError"));
    } finally {
      setUpdatingStatus(false);
    }
  };

  const handleStartChat = () => {
    if (!selectedJob || !userProfile) return;

    const otherParticipantId =
      userRole === "driver"
        ? selectedJob.merchantId
        : selectedJob.assignedDriverId;

    if (!otherParticipantId) {
      Alert.alert(t("errors.general"), t("jobs.noDriverAssigned"));
      return;
    }

    const conversationId = getOrCreateConversation(
      [userProfile.id, otherParticipantId],
      selectedJob.id
    );
    (navigation as any).navigate(Routes.ChatScreen, { conversationId });
  };

  const handleStartCall = () => {
    if (!selectedJob || !userProfile) return;

    const otherParticipantId =
      userRole === "driver"
        ? selectedJob.merchantId
        : selectedJob.assignedDriverId;
    const otherParticipantName =
      userRole === "driver" ? selectedJob.merchantName : t("jobs.driver");

    if (!otherParticipantId) {
      Alert.alert(t("errors.general"), t("jobs.noDriverAssigned"));
      return;
    }

    const call = initiateCall(
      userProfile.id,
      userProfile.name,
      otherParticipantId,
      otherParticipantName,
      selectedJob.id
    );
    (navigation as any).navigate("CallScreen", { callId: call.id });
  };

  const handleVerification = (
    verificationType: "start" | "finish" | "pre_trip" | "post_trip"
  ) => {
    if (!selectedJob) return;
    (navigation as any).navigate(Routes.VerificationCameraScreen, {
      jobId: selectedJob.id,
      type: verificationType,
    });
  };

  const getNextStatus = (): Job["status"] | null => {
    if (!selectedJob) return null;

    switch (selectedJob.status) {
      case "assigned":
        return "in_progress";
      case "in_progress":
        return "arrived_pickup";
      case "arrived_pickup":
        return "loaded";
      case "loaded":
        return "in_transit";
      case "in_transit":
        return "arrived_delivery";
      case "arrived_delivery":
        return "delivered";
      default:
        return null;
    }
  };

  const getStatusButtonText = (): string => {
    const nextStatus = getNextStatus();
    if (!nextStatus) return "";
    return t(`jobStatus.${nextStatus}.button`);
  };

  const formatStatus = (status: string) => {
    return t(`jobStatus.${status}.label`, { defaultValue: status });
  };

  const renderLocationPermissionRequest = () => (
    <View style={styles.permissionContainer}>
      <AlertCircle
        size={40}
        color={Colors.warning}
        style={styles.permissionIcon}
      />
      <Text style={styles.permissionTitle}>
        {t("tracking.permission.title")}
      </Text>
      <Text style={styles.permissionText}>
        {t("tracking.permission.message")}
      </Text>
      <Button
        title={t("tracking.permission.button")}
        variant="primary"
        onPress={handleRequestPermission}
        style={styles.permissionButton}
      />
    </View>
  );

  const renderNoActiveJobs = () => (
    <View style={styles.emptyContainer}>
      <MapPin size={40} color={Colors.gray400} style={styles.emptyIcon} />
      <Text style={styles.emptyTitle}>{t("tracking.noJobs.title")}</Text>
      <Text style={styles.emptyText}>
        {userRole === "driver"
          ? t("tracking.noJobs.driverMessage")
          : t("tracking.noJobs.merchantMessage")}
      </Text>
    </View>
  );

  const renderMapView = () => {
    // Default coordinates for New York City
    const defaultLocation = {
      latitude: 40.7589,
      longitude: -73.9851,
    };

    // Dummy data for demonstration when no job is selected
    const dummyJob = {
      pickupLocation: {
        lat: 40.7505,
        lng: -73.9934,
        address: "456 Business Ave, New York, NY 10002"
      },
      dropoffLocation: {
        lat: 40.7282,
        lng: -73.9942,
        address: "321 Corporate Plaza, Manhattan, NY 10003"
      }
    };

    const jobToUse = selectedJob || dummyJob;

    const coordinates = [
      {
        latitude: currentLocation?.latitude || defaultLocation.latitude,
        longitude: currentLocation?.longitude || defaultLocation.longitude,
        title: "Your Location",
        description: currentLocation ? "Current driver location" : "Default location",
        type: "driver"
      },
      {
        latitude: jobToUse.pickupLocation.lat,
        longitude: jobToUse.pickupLocation.lng,
        title: "Pickup Location",
        description: jobToUse.pickupLocation.address,
        type: "pickup"
      },
      {
        latitude: jobToUse.dropoffLocation.lat,
        longitude: jobToUse.dropoffLocation.lng,
        title: "Delivery Location",
        description: jobToUse.dropoffLocation.address,
        type: "delivery"
      },
    ].filter(coord => coord.latitude !== 0 && coord.longitude !== 0);

    return (
      <View style={styles.mapViewContainer}>
        {/* Dummy data indicator */}
        {!selectedJob ? (
          <View style={styles.dummyDataIndicator}>
            <Text style={styles.dummyDataText}>📍 Demo Map - Showing Sample Locations</Text>
          </View>
        ) : null}


        
        <MapView
          ref={mapRef}
          style={styles.map}
          region={mapRegion}
          provider= {PROVIDER_GOOGLE}
          onRegionChangeComplete={setMapRegion}
          showsUserLocation={false}
          showsMyLocationButton={false}
          showsCompass={false}
          showsScale={false}
          mapType="standard"
          initialRegion={mapRegion}
          loadingEnabled={false}
          loadingIndicatorColor={Colors.primary}
          loadingBackgroundColor={Colors.background}
          onMapReady={() => {
            console.log("Map is ready!");
            setMapReady(true);
            setTimeout(() => {
              fitMapToMarkers();
            }, 1000);
          }}
        >
          {coordinates.map((coord, index) => {
            const getPinColor = () => {
              if (coord.type === 'driver') return '#00FF00';
              if (coord.type === 'pickup') return '#FF6B35';
              return '#4ECDC4';
            };

            return (
              <Marker
                key={`${coord.type}-${index}`}
                coordinate={{
                  latitude: coord.latitude,
                  longitude: coord.longitude,
                }}
                title={coord.title}
                description={coord.description}
                pinColor={getPinColor()}
              />
            );
          })}
          
          {/* Route polyline */}
          {coordinates.length >= 2 && (
            <Polyline
              coordinates={coordinates.map(coord => ({
                latitude: coord.latitude,
                longitude: coord.longitude,
              }))}
              strokeColor="#007AFF"
              strokeWidth={3}
              lineDashPattern={[5, 5]}
            />
          )}
        </MapView>

        {/* Map Controls */}
        <View style={styles.mapControls}>
          <TouchableOpacity style={styles.mapControlButton} onPress={handleZoomIn}>
            <ZoomIn size={20} color={Colors.white} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.mapControlButton} onPress={handleZoomOut}>
            <ZoomOut size={20} color={Colors.white} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.mapControlButton} onPress={handleLocateMe}>
            <Locate size={20} color={Colors.white} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.mapControlButton} onPress={handleFitToMarkers}>
            <Route size={20} color={Colors.white} />
          </TouchableOpacity>
        </View>

        {/* Distance and ETA Info */}
        <View style={styles.mapInfo}>
          <View style={styles.mapInfoItem}>
            <Text style={styles.mapInfoLabel}>To Pickup</Text>
            <Text style={styles.mapInfoValue}>
              {distanceToPickup ? `${distanceToPickup.toFixed(1)} km` : '--'}
            </Text>
            <Text style={styles.mapInfoEta}>
              ETA: {etaToPickup || '--'}
            </Text>
          </View>
          <View style={styles.mapInfoItem}>
            <Text style={styles.mapInfoLabel}>To Delivery</Text>
            <Text style={styles.mapInfoValue}>
              {distanceToDelivery ? `${distanceToDelivery.toFixed(1)} km` : '--'}
            </Text>
            <Text style={styles.mapInfoEta}>
              ETA: {etaToDelivery || '--'}
            </Text>
          </View>
        </View>

        {/* Fallback view if map fails to load */}
        {!mapReady ? (
          <View style={styles.mapFallback}>
            <MapPin size={48} color={Colors.gray400} />
            <Text style={styles.mapFallbackTitle}>Map Loading...</Text>
            <Text style={styles.mapFallbackText}>
              {selectedJob ? 'Loading job locations...' : 'Loading sample locations...'}
            </Text>
          </View>
        ) : null}
      </View>
    );
  };

  const renderJobSelector = () => (
    <View style={styles.jobSelectorContainer}>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.jobSelectorContent}
        style={styles.jobSelectorScrollView}
      >
        {displayJobs.map((job) => (
          <TouchableOpacity
            key={job.id}
            style={[
              styles.jobSelectorItem,
              selectedJob?.id === job.id && styles.jobSelectorItemActive,
            ]}
            onPress={() => setSelectedJob(job)}
          >
            <Text
              style={[
                styles.jobSelectorTitle,
                selectedJob?.id === job.id && styles.jobSelectorTitleActive,
              ]}
              numberOfLines={1}
            >
              {job.title}
            </Text>
            <Text
              style={[
                styles.jobSelectorStatus,
                selectedJob?.id === job.id && styles.jobSelectorStatusActive,
              ]}
            >
              {formatStatus(job.status)}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );

  const renderViewToggle = () => (
    <View style={styles.viewToggleContainer}>
      <TouchableOpacity
        style={[
          styles.viewToggleButton,
          mapView === 'map' && styles.viewToggleButtonActive,
        ]}
        onPress={() => setMapView('map')}
      >
        <MapPin size={16} color={mapView === 'map' ? Colors.white : Colors.primary} />
        <Text
          style={[
            styles.viewToggleText,
            mapView === 'map' && styles.viewToggleTextActive,
          ]}
        >
          Map
        </Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={[
          styles.viewToggleButton,
          mapView === 'list' && styles.viewToggleButtonActive,
        ]}
        onPress={() => setMapView('list')}
      >
        <Navigation size={16} color={mapView === 'list' ? Colors.white : Colors.primary} />
        <Text
          style={[
            styles.viewToggleText,
            mapView === 'list' && styles.viewToggleTextActive,
          ]}
        >
          List
        </Text>
      </TouchableOpacity>
   
    </View>
  );

  const renderVerificationButtons = () => {
    if (!selectedJob || userRole !== "driver") return null;

    const showStartVerification = selectedJob.status === "assigned";
    const showFinishVerification = selectedJob.status === "arrived_delivery";
    const showPreTripVerification = ["assigned", "in_progress"].includes(
      selectedJob.status
    );
    const showPostTripVerification = ["arrived_delivery", "delivered"].includes(
      selectedJob.status
    );

    return (
      <View style={styles.verificationContainer}>
        <Text style={styles.verificationTitle}>
          {t("tracking.verification.title")}
        </Text>
        <View style={styles.verificationButtons}>
          {showStartVerification && (
            <TouchableOpacity
              style={styles.verificationButton}
              onPress={() => handleVerification("start")}
            >
              <Camera
                size={20}
                color={Colors.white}
                style={styles.verificationIcon}
              />
              <Text style={styles.verificationButtonText}>
                {t("tracking.verification.start")}
              </Text>
            </TouchableOpacity>
          )}
          {showFinishVerification && (
            <TouchableOpacity
              style={styles.verificationButton}
              onPress={() => handleVerification("finish")}
            >
              <Camera
                size={20}
                color={Colors.success}
                style={styles.verificationIcon}
              />
              <Text style={styles.verificationButtonText}>
                {t("tracking.verification.finish")}
              </Text>
            </TouchableOpacity>
          )}
          {showPreTripVerification && (
            <TouchableOpacity
              style={styles.verificationButton}
              onPress={() => handleVerification("pre_trip")}
            >
              <Camera
                size={20}
                color={Colors.white}
                style={styles.verificationIcon}
              />
              <Text style={styles.verificationButtonText}>
                {t("tracking.verification.preTrip")}
              </Text>
            </TouchableOpacity>
          )}
          {showPostTripVerification && (
            <TouchableOpacity
              style={styles.verificationButton}
              onPress={() => handleVerification("post_trip")}
            >
              <Camera
                size={20}
                color={Colors.secondary}
                style={styles.verificationIcon}
              />
              <Text style={styles.verificationButtonText}>
                {t("tracking.verification.postTrip")}
              </Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    );
  };

  const renderCommunicationButtons = () => {
    if (!selectedJob) return null;

    return (
      <View style={styles.communicationContainer}>
        <TouchableOpacity
          style={styles.communicationButton}
          onPress={handleStartChat}
        >
          <MessageCircle size={20} color={Colors.primary} />
          <Text style={styles.communicationButtonText}>
            {t("common.message")}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.communicationButton}
          onPress={handleStartCall}
        >
          <Phone size={20} color={Colors.primary} />
          <Text style={styles.communicationButtonText}>{t("common.call")}</Text>
        </TouchableOpacity>
      </View>
    );
  };

  const renderTrackingInfo = () => {
    if (!selectedJob) return null;

    return (
      <View style={styles.trackingContainer}>
        <View style={styles.statusContainer}>
          <View
            style={[
              styles.statusBadge,
              { backgroundColor: getStatusColor(selectedJob.status) },
            ]}
          >
            <Text style={styles.statusText}>
              {formatStatus(selectedJob.status)}
            </Text>
          </View>

          {userRole === "driver" && getNextStatus() && (
            <Button
              title={getStatusButtonText()}
              variant="primary"
              loading={updatingStatus}
              onPress={() => {
                const nextStatus = getNextStatus();
                if (nextStatus) {
                  handleUpdateStatus(nextStatus);
                }
              }}
              style={styles.updateButton}
            />
          )}
        </View>

        {renderCommunicationButtons()}
        {renderVerificationButtons()}

        <View style={styles.locationContainer}>
          <View style={styles.locationHeader}>
            <MapPin size={20} color={Colors.primary} />
            <Text style={styles.locationTitle}>
              {t("tracking.currentLocation")}
            </Text>
          </View>

          {currentLocation ? (
            <View style={styles.currentLocationInfo}>
              <Text style={styles.coordinatesText}>
                {t("tracking.coordinates", {
                  lat: currentLocation.latitude.toFixed(6),
                  lng: currentLocation.longitude.toFixed(6),
                })}
              </Text>
              <Text style={styles.updatedText}>
                {t("tracking.updatedAt", {
                  time: new Date(
                    currentLocation.timestamp
                  ).toLocaleTimeString(),
                })}
              </Text>

              {isTracking ? (
                <View style={styles.trackingStatus}>
                  <View style={styles.trackingIndicator} />
                  <Text style={styles.trackingText}>
                    {t("tracking.liveTracking")}
                  </Text>
                </View>
              ) : (
                <Button
                  title={t("tracking.startTracking")}
                  variant="outline"
                  onPress={startLocationTracking}
                  style={styles.startTrackingButton}
                />
              )}
            </View>
          ) : (
            <Text style={styles.noLocationText}>
              {t("tracking.noLocationData")}
            </Text>
          )}
        </View>

        <View style={styles.routeContainer}>
          <View style={styles.routePoint}>
            <View style={[styles.routeMarker, styles.pickupMarker]}>
              <MapPin size={16} color={Colors.white} />
            </View>
            <View style={styles.routeInfo}>
              <Text style={styles.routeLabel}>{t("jobs.pickup")}</Text>
              <Text style={styles.routeAddress}>
                {selectedJob.pickupLocation.address}
              </Text>
              <Text style={styles.routeCity}>
                {selectedJob.pickupLocation.city}, {selectedJob.pickupLocation.state}{" "}
                {selectedJob.pickupLocation.zipCode}
              </Text>
              <Text style={styles.routeTime}>
                {selectedJob.pickupLocation.date} • {selectedJob.pickupLocation.time}
              </Text>
            </View>
          </View>

          <View style={styles.routeConnector} />

          <View style={styles.routePoint}>
            <View style={[styles.routeMarker, styles.deliveryMarker]}>
              <MapPin size={16} color={Colors.white} />
            </View>
            <View style={styles.routeInfo}>
              <Text style={styles.routeLabel}>{t("jobs.delivery")}</Text>
              <Text style={styles.routeAddress}>
                {selectedJob.dropoffLocation.address}
              </Text>
              <Text style={styles.routeCity}>
                {selectedJob.dropoffLocation.city}, {selectedJob.dropoffLocation.state}{" "}
                {selectedJob.dropoffLocation.zipCode}
              </Text>
              <Text style={styles.routeTime}>
                {selectedJob.dropoffLocation.date} • {selectedJob.dropoffLocation.time}
              </Text>
            </View>
          </View>
        </View>

        <View style={styles.detailsContainer}>
          <View style={styles.detailItem}>
            <Clock size={16} color={Colors.gray600} style={styles.detailIcon} />
            <View>
              <Text style={styles.detailLabel}>
                {t("jobs.estimatedDuration")}
              </Text>
              <Text style={styles.detailValue}>
                {selectedJob.estimatedDuration}
              </Text>
            </View>
          </View>

          <View style={styles.detailItem}>
            <Navigation
              size={16}
              color={Colors.gray600}
              style={styles.detailIcon}
            />
            <View>
              <Text style={styles.detailLabel}>{t("jobs.distance")}</Text>
              <Text style={styles.detailValue}>
                {t("common.distance", { value: selectedJob.distance })}
              </Text>
            </View>
          </View>

          <View style={styles.detailItem}>
            <CheckCircle
              size={16}
              color={Colors.gray600}
              style={styles.detailIcon}
            />
            <View>
              <Text style={styles.detailLabel}>{t("jobs.cargoType")}</Text>
              <Text style={styles.detailValue}>{selectedJob.cargoType}</Text>
            </View>
          </View>
        </View>

        {selectedJob.specialRequirements && (
          <View style={styles.requirementsContainer}>
            <Text style={styles.requirementsTitle}>
              {t("jobs.specialRequirements")}
            </Text>
            <Text style={styles.requirementsText}>
              {selectedJob.specialRequirements}
            </Text>
          </View>
        )}
      </View>
    );
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "posted":
        return Colors.primary;
      case "active":
        return Colors.primary;
      case "assigned":
        return Colors.warning;
      case "in_progress":
      case "arrived_pickup":
      case "loaded":
      case "in_transit":
      case "arrived_delivery":
        return Colors.secondary;
      case "delivered":
      case "completed":
        return Colors.success;
      case "cancelled":
        return Colors.error;
      default:
        return Colors.gray500;
    }
  };

  return (
    <View style={styles.container}>
      {/* Mock data indicator */}
      {activeJobs.length === 0 && displayJobs.length > 0 && (
        <View style={styles.mockDataIndicator}>
          <Text style={styles.mockDataText}>📱 Demo Mode - Showing Sample Jobs</Text>
        </View>
      )}
      
      {(() => {
        if (userRole === "driver" && !locationPermission) {
          return renderLocationPermissionRequest();
        }
        if (displayJobs.length === 0) {
          return renderNoActiveJobs();
        }
        return (
          <View style={styles.mainContent}>
            {/* {displayJobs.length > 1 && renderJobSelector()} */}
            {renderViewToggle()}
            
            {mapView === 'map' ? (
              renderMapView()
            ) : (
              <ScrollView
                style={styles.scrollView}
                contentContainerStyle={styles.scrollContent}
                showsVerticalScrollIndicator={false}
              >
                {renderTrackingInfo()}
              </ScrollView>
            )}
          </View>
        );
      })()}
    </View>
  );
}

export { TrackingScreen };
