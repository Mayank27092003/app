/**
 * @format
 * Tracking Module
 */

import { TrackingScreen } from './view/tracking';

export { TrackingScreen };
