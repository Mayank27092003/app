/**
 * @format
 * Auth Module
 */

import { LoginScreen } from './view/login';
import { OTPScreen } from './view/otp';
import { RegisterScreen } from './view/register';
import { RoleSelectScreen } from './view/role-select';
import { ForgetPassword } from './view/forgetPassword';
import ResetPasswordScreen from './view/resetPassword';
export { LoginScreen, OTPScreen, RegisterScreen, RoleSelectScreen, ForgetPassword, ResetPasswordScreen };
