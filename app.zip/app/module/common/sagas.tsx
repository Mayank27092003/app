/**
 * Common sagas
 * @format
 */

import { call, put, takeLatest } from "redux-saga/effects";
import { presentLoader, dismissLoader, setDocumentTypes, fetchDocumentTypes, uploadDocument, setProfile, deleteDocument } from "./slice";
import { showMessage } from "react-native-flash-message";
import { endPoints, httpRequest } from "@app/service";

/**
 * Upload document saga
 * @param {*} action - Upload document action with document data
 */
function* uploadDocumentSaga(action: any): any {
  try {
    yield put(presentLoader());
    const { documentData, onSuccess, onError } = action.payload;
console.log("documentData", documentData);
    // Make the document upload request
    const response = yield call(httpRequest.post, endPoints.documentUpload, documentData);

    if (response?.success) {
      showMessage({
        message: "Document uploaded successfully!",
        type: "success",
      });

      if (onSuccess) {
        onSuccess(response);
      }
    } else {
      const errorMessage = response?.message || "Document upload failed. Please try again.";
      
      showMessage({
        message: errorMessage,
        type: "danger",
      });

      if (onError) {
        onError(response);
      }
    }
  } catch (error: any) {
    const errorMessage = error?.message || "Document upload failed. Please try again.";
    
    showMessage({
      message: errorMessage,
      type: "danger",
    });

    if (action.payload.onError) {
      action.payload.onError(error);
    }
  } finally {
    yield put(dismissLoader());
  }
}

/**
 * Fetch user documents saga
 */
function* fetchUserDocumentsSaga(): any {
  try {
    yield put(presentLoader());
    
    const response = yield call(httpRequest.get, endPoints.userDocuments);

    if (response?.success) {
      // Update the profile with documents
      yield put(setProfile({ 
        ...response.data,
        documents: response.data.documents || []
      }));
    } else if (response && Array.isArray(response)) {
      // Handle case where API returns array directly
      yield put(setProfile({ 
        documents: response 
      }));
    } else if (response && response.data && Array.isArray(response.data)) {
      // Handle case where API returns {data: [...]} without success flag
      yield put(setProfile({ 
        documents: response.data 
      }));
    } else {
      showMessage({
        message: "Unexpected response format from documents API",
        type: "danger",
      });
    }
  } catch (error: any) {
    showMessage({
      message: error?.message || "Failed to fetch user documents",
      type: "danger",
    });
  } finally {
    yield put(dismissLoader());
  }
}

/**
 * Fetch document types saga
 */
function* fetchDocumentTypesSaga(): any {
  try {
    yield put(presentLoader());
    
    const response = yield call(httpRequest.get, endPoints.documentTypes);

    if (response?.success) {
      yield put(setDocumentTypes(response.data || []));
    } else if (response && Array.isArray(response)) {
      // Handle case where API returns array directly
      yield put(setDocumentTypes(response));
    } else if (response && response.data && Array.isArray(response.data)) {
      // Handle case where API returns {data: [...]} without success flag
      yield put(setDocumentTypes(response.data));
    } else {
      showMessage({
        message: "Unexpected response format from API",
        type: "danger",
      });
    }
  } catch (error: any) {
    showMessage({
      message: error?.message || "Failed to fetch document types",
      type: "danger",
    });
  } finally {
    yield put(dismissLoader());
  }
}

/**
 * File upload action saga
 * @param {*} action - Upload action with file data
 */
function* uploadFileSaga(action: any): any {
  try {
    yield put(presentLoader());
    const { file, onSuccess, onError } = action.payload;

    // Create FormData for multipart/form-data
    const formData = new FormData();
    const fileBlob = {
      uri: file.uri,
      type: file.type || 'application/octet-stream',
      name: file.name || 'file',
    } as any;
    
    formData.append('file', fileBlob);
console.log("formData for doccc", formData);
    // Make the actual upload request to the API
    const response = yield call(httpRequest.post, endPoints.upload, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });

    if (response) {
      console.log(response, "response upload file");
      showMessage({
        message: "File uploaded successfully!",
        type: "success",
      });

      onSuccess(response);
    } else {
      const errorMessage = response?.message || "Upload failed. Please try again.";
      
      showMessage({
        message: errorMessage,
        type: "danger",
      });

      if (onError) {
        onError(response);
      }
    }
  } catch (error: any) {
    const errorMessage = error?.message || "Upload failed. Please try again.";
    
    showMessage({
      message: errorMessage,
      type: "danger",
    });

    if (action.payload.onError) {
      action.payload.onError(error);
    }
  } finally {
    yield put(dismissLoader());
  }
}

function* deleteDocumentSaga(action: any): any {
  try {
    yield put(presentLoader());
    const { documentId, onSuccess, onError } = action.payload;
    
    const response = yield call(httpRequest.delete, endPoints.documentDelete(documentId));
    console.log("response delete", response);
    if (response?.success) {
      showMessage({ message: "Document deleted successfully!", type: "success" });
      if (onSuccess) { onSuccess(); }
    } else {
      const errorMessage = response?.message || "Document deletion failed. Please try again.";
      showMessage({ message: errorMessage, type: "danger" });
      if (onError) { onError(response); }
    }
  } catch (error: any) {
    const errorMessage = error?.message || "Document deletion failed. Please try again.";
    showMessage({ message: errorMessage, type: "danger" });
    if (action.payload.onError) { action.payload.onError(error); }
  } finally {
    yield put(dismissLoader());
  }
}

/**
 * Common sagas
 */
export function* commonSagas() {
  yield takeLatest("COMMON/UPLOAD_FILE", uploadFileSaga);
  yield takeLatest("COMMON/UPLOAD_DOCUMENT", uploadDocumentSaga);
  yield takeLatest("COMMON/DELETE_DOCUMENT", deleteDocumentSaga);
  yield takeLatest(fetchDocumentTypes, fetchDocumentTypesSaga);
  yield takeLatest("COMMON/FETCH_USER_DOCUMENTS", fetchUserDocumentsSaga);
} 