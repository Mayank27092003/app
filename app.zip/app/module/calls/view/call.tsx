/**
 * Call Screen
 * @format
 */

import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import {
  Phone,
  PhoneOff,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  User,
  ArrowLeft,
  Clock,
} from 'lucide-react-native';
import { useDispatch } from 'react-redux';

//Screens
import { Colors } from '@app/styles';
import { useAuthStore } from '@app/store/authStore';
import { useChatStore } from '@app/store/chatStore';
import { Call } from '@app/types';
import { useThemedStyle } from '@app/styles';
import { getStyles } from './styles';

type RootStackParamList = {
  CallScreen: { id: string };
};
type CallScreenRouteProp = RouteProp<RootStackParamList, 'CallScreen'>;

function CallScreen() {
  const styles = useThemedStyle(getStyles);
  const navigation = useNavigation();
  const route = useRoute<CallScreenRouteProp>();

  const { callId } = route.params;
  console.log(route.params,'id dataa')

  const { userProfile } = useAuthStore();
  const { calls, updateCallStatus } = useChatStore();
  const [call, setCall] = useState<Call | null>(null);
  const [callDuration, setCallDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeakerOn, setIsSpeakerOn] = useState(false);
  const disptach = useDispatch();

  useEffect(() => {
    // console.log(id,'id dataa')

    if (callId) {
      const callData = calls.find((c: { id: any; }) => c.id === callId);
      if (callData) {
        console.log(callData,'caldataaaaaa')
        setCall(callData);
      } else {
        // Call not found, navigate back
        navigation.goBack();
      }
    }
  }, [callId, calls]);

  useEffect(() => {
    let intervalId: NodeJS.Timeout;

    if (call && call.status === 'in_progress') {
      // Start timer for call duration
      intervalId = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);
    }

    return () => {
      if (intervalId) {
        clearInterval(intervalId);
      }
    };
  }, [call]);

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;

    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const handleAnswerCall = () => {
    if (!call) return;

    updateCallStatus(call.id, 'in_progress');
    setCall({ ...call, status: 'in_progress' });
  };

  const handleEndCall = () => {
    if (!call) return;

    updateCallStatus(
      call.id,
      'completed',
      new Date().toISOString(),
      callDuration,
    );

    // Navigate back after ending call
    setTimeout(() => {
      navigation.goBack();
    }, 500);
  };

  const handleToggleMute = () => {
    setIsMuted(prev => !prev);
  };

  const handleToggleSpeaker = () => {
    setIsSpeakerOn(prev => !prev);
  };

  const getContactName = () => {
    if (!call || !userProfile) return '';

    return call.callerId === userProfile.id
      ? call.receiverName
      : call.callerName;
  };

  const isIncoming =
    call?.receiverId === userProfile?.id && call.status === 'incoming';
  const isActive = call?.status === 'in_progress';

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <ArrowLeft size={24} color={Colors.white} />
        </TouchableOpacity>

        {call?.jobId && (
          <View style={styles.jobBadge}>
            <Text style={styles.jobBadgeText}>
              Job #{call.jobId.substring(1, 6)}
            </Text>
          </View>
        )}
      </View>

      <View style={styles.contactContainer}>
        <View style={styles.avatarContainer}>
          <View style={styles.avatar}>
            <User size={40} color={Colors.white} />
          </View>
        </View>

        <Text style={styles.contactName}>{getContactName()}</Text>

        <Text style={styles.callStatus}>
          {isIncoming
            ? 'Incoming call...'
            : isActive
            ? 'Call in progress'
            : call?.status === 'outgoing'
            ? 'Calling...'
            : call?.status === 'completed'
            ? 'Call ended'
            : call?.status === 'missed'
            ? 'Missed call'
            : call?.status === 'failed'
            ? 'Call failed'
            : ''}
        </Text>

        {(isActive || call?.status === 'completed') && (
          <View style={styles.durationContainer}>
            <Clock size={16} color={Colors.white} style={styles.durationIcon} />
            <Text style={styles.duration}>
              {formatDuration(callDuration || call?.duration || 0)}
            </Text>
          </View>
        )}
      </View>

      <View style={styles.actionsContainer}>
        {isActive && (
          <>
            <TouchableOpacity
              style={[
                styles.actionButton,
                isMuted && styles.actionButtonActive,
              ]}
              onPress={handleToggleMute}
            >
              {isMuted ? (
                <MicOff size={24} color={Colors.white} />
              ) : (
                <Mic size={24} color={Colors.white} />
              )}
              <Text style={styles.actionText}>
                {isMuted ? 'Unmute' : 'Mute'}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[
                styles.actionButton,
                isSpeakerOn && styles.actionButtonActive,
              ]}
              onPress={handleToggleSpeaker}
            >
              {isSpeakerOn ? (
                <Volume2 size={24} color={Colors.white} />
              ) : (
                <VolumeX size={24} color={Colors.white} />
              )}
              <Text style={styles.actionText}>
                {isSpeakerOn ? 'Speaker' : 'Earpiece'}
              </Text>
            </TouchableOpacity>
          </>
        )}
      </View>

      <View style={styles.callButtonsContainer}>
        {isIncoming ? (
          <>
            <TouchableOpacity
              style={[styles.callButton, styles.declineButton]}
              onPress={handleEndCall}
            >
              <PhoneOff size={32} color={Colors.white} />
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.callButton, styles.answerButton]}
              onPress={handleAnswerCall}
            >
              <Phone size={32} color={Colors.white} />
            </TouchableOpacity>
          </>
        ) : isActive ? (
          <TouchableOpacity
            style={[styles.callButton, styles.endButton]}
            onPress={handleEndCall}
          >
            <PhoneOff size={32} color={Colors.white} />
          </TouchableOpacity>
        ) : null}
      </View>

      {call?.recorded && (
        <View style={styles.recordingContainer}>
          <View style={styles.recordingIndicator} />
          <Text style={styles.recordingText}>
            This call is being recorded for quality and transparency purposes
          </Text>
        </View>
      )}
    </View>
  );
}

export { CallScreen };
