/**
 * @format
 * Call Module
 */

import { CallScreen } from './view/call';
import { CallHistoryScreen } from './view/history';

export { CallScreen, CallHistoryScreen };
