/**
 * Chat Screen
 * @format
 */

import React, { useState, useEffect, useRef } from "react";
import {
  View,
  Text,
  FlatList,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  Image,
  ActivityIndicator,
  Dimensions,
  Keyboard,
  Modal,
  Alert,
} from "react-native";
import { useNavigation, useRoute, RouteProp } from "@react-navigation/native";
import {
  ArrowLeft,
  Send,
  Phone,
  MoreVertical,
  Paperclip,
  Mic,
  Image as ImageIcon,
  MapPin,
  File,
  X,
  Check,
  CheckCheck,
  Clock,
  Camera,
  Download,
} from "lucide-react-native";
import { useSelector, useDispatch } from "react-redux";
import { WebView } from "react-native-webview";
import RNFS from "react-native-fs";

//Screens
import { Colors, useThemedStyle } from "@app/styles";
import { useChatStore } from "@app/store/chatStore";
import { selectProfile } from "@app/module/common";
import { mockMerchants } from "@app/mocks/users";
import { Message, MessageStatus, Conversation } from "@app/types";
import { getStyles } from "./styles";
import { useTranslation } from "react-i18next";
import {
  launchImageLibrary,
  launchCamera,
  ImagePickerResponse,
  MediaType,
} from "react-native-image-picker";
// import DocumentPicker from '@react-native-documents/picker';
import { pick, types } from "@react-native-documents/picker";

import {
  fetchConversationById,
  fetchAllConversations,
  sendMessageToConversation,
  ConversationResponse,
  MessageResponse,
  SendMessageRequest,
  UploadFileResponse,
} from "@app/service/conversations-service";
import { createLoader, uploadFile } from "../../common";
import { showMessage } from "react-native-flash-message";
import FullScreenDocumentViewer from "@app/components/DocumentViewerModal";

type RootStackParamList = {
  CallScreen: { userId: string };
  ChatScreen: {
    conversationId: string;
    selectedParticipant?: {
      id: string;
      userName: string;
      firstName?: string;
      lastName?: string;
      profileImage?: string;
      phoneNumber?: string;
      phoneCountryCode?: string;
      role?: string;
      isOnline?: boolean;
      lastSeen?: string;
    };
  };
  GroupDetailsScreen: {
    conversation: Conversation;
    participants: Array<{
      id: string;
      userName: string;
      firstName?: string;
      lastName?: string;
      profileImage?: string;
      isOnline?: boolean;
      lastSeen?: string;
    }>;
  };
};
type ChatScreenRouteProp = RouteProp<RootStackParamList, "ChatScreen">;
const { width: SCREEN_WIDTH } = Dimensions.get("window");
const downloadFile = async (fileUrl: string) => {
  console.log("Chat screen - Downloading file:eeee", fileUrl);
  try {
    const fileName = fileUrl.split("/").pop(); // extract file name from url
    const localPath = `${RNFS.DownloadDirectoryPath}/${fileName}`; // save to Downloads folder (Android)

    const options = {
      fromUrl: fileUrl,
      toFile: localPath,
    };

    const result = await RNFS.downloadFile(options).promise;

    if (result.statusCode === 200) {
      Alert.alert("Success", `File downloaded to: ${localPath}`);
      console.log("File saved at:", localPath);
    } else {
      Alert.alert("Error", "Failed to download file.");
    }
  } catch (err) {
    console.error("Download error:", err);
    Alert.alert("Error", "Something went wrong while downloading.");
  }
};
function ChatScreen() {
  const { t } = useTranslation();

  const styles = useThemedStyle(getStyles);
  const navigation = useNavigation();
  const route = useRoute<ChatScreenRouteProp>();

  console.log("Chat screen - Full route object:", route);
  console.log("Chat screen - route.params:", route?.params);
  console.log("Chat screen - route.params type:", typeof route?.params);
  const [loading, setLoading] = useState(true);

  const { conversationId, selectedParticipant, conversationItem } =
    route?.params || {};
  console.log("Chat screen - conversationItem:", conversationItem);
  console.log("Chat screen - conversationId type:", typeof conversationId);
  console.log("Chat screen - selectedParticipant:", selectedParticipant);
  console.log("Chat screen - conversationId length:", conversationId?.length);
  console.log(
    "Chat screen - conversationId is undefined:",
    conversationId === undefined
  );
  console.log("Chat screen - conversationId is null:", conversationId === null);
  const userProfile = useSelector(selectProfile);
  const dispatch = useDispatch();
  console.log("Chat screen - userProfile:", userProfile);
  const {
    getConversation,
    sendMessage,
    markAsRead,
    startTyping,
    stopTyping,
    isTyping,
    onlineUsers,
    getOnlineUsers,
    isUserOnline,
    getOnlineUser,
  } = useChatStore();

  const [conversation, setConversation] = useState<Conversation | undefined>(
    undefined
  );
  const [isLoadingConversation, setIsLoadingConversation] = useState(false);
  const [conversationError, setConversationError] = useState<string | null>(
    null
  );
  const [apiConversation, setApiConversation] =
    useState<ConversationResponse | null>(null);
  const [socketMessages, setSocketMessages] = useState<Message[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [hasMoreMessages, setHasMoreMessages] = useState(true);
  const [allApiMessages, setAllApiMessages] = useState<MessageResponse[]>([]);
  const [showImageModal, setShowImageModal] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [imageText, setImageText] = useState("");
  const [showImagePicker, setShowImagePicker] = useState(false);
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const [showFullImageModal, setShowFullImageModal] = useState(false);
  const [fullImageUrl, setFullImageUrl] = useState<string | null>(null);
  const [isUserAtBottom, setIsUserAtBottom] = useState(true);
  const [shouldAutoScroll, setShouldAutoScroll] = useState(true);

  console.log("Chat screen - conversation state:", conversation);

  // Function to add socket message to the list
  const addSocketMessage = (message: Message) => {
    console.log("Chat screen - Adding socket message:", message);
    setSocketMessages((prev) => {
      // Check if message already exists to prevent duplicates
      const exists = prev.some((msg) => msg.id === message.id);
      if (exists) {
        console.log(
          "Chat screen - Message already exists, skipping:",
          message.id
        );
        return prev;
      }
      return [...prev, message];
    });

    // Auto-scroll to bottom when new message is added
    if (shouldAutoScroll) {
      setTimeout(() => {
        flatListRef.current?.scrollToEnd({ animated: true });
      }, 100);
    }
  };

  // Handle scroll events to detect if user is at bottom
  const handleScroll = (event: any) => {
    const { contentOffset, contentSize, layoutMeasurement } = event.nativeEvent;
    const isAtBottom =
      contentOffset.y + layoutMeasurement.height >= contentSize.height - 20;
    setIsUserAtBottom(isAtBottom);

    // If user scrolls to bottom, enable auto-scroll
    if (isAtBottom) {
      setShouldAutoScroll(true);
    }
  };

  // Handle scroll to bottom when user manually scrolls to bottom
  const scrollToBottom = () => {
    setShouldAutoScroll(true);
    flatListRef.current?.scrollToEnd({ animated: true });
  };

  // Get the other participant's online status
  const getOtherParticipantStatus = () => {
    if (!selectedParticipant?.id) return null;

    const onlineUser = getOnlineUser(selectedParticipant.id);
    const isOnline = onlineUser?.isOnline || false;

    return {
      isOnline,
      lastSeen: onlineUser?.lastSeen,
      name:
        onlineUser?.name ||
        selectedParticipant.userName ||
        selectedParticipant.firstName ||
        "User",
      avatar: onlineUser?.avatar || selectedParticipant.profileImage,
      email: onlineUser?.email,
    };
  };

  // Function to get all messages (API + Socket)
  const getAllMessages = () => {
    // Use accumulated API messages as base
    const allMessages = [...allApiMessages];

    // Add socket messages that are not already in API messages
    socketMessages.forEach((socketMsg) => {
      const existsInApi = allApiMessages.some(
        (apiMsg) => apiMsg.id.toString() === socketMsg.id.toString()
      );
      if (!existsInApi) {
        allMessages.push(socketMsg);
      }
    });

    // Sort by timestamp to maintain correct order
    return allMessages.sort((a, b) => {
      const timeA = new Date(a.sentAt || a.timestamp || 0).getTime();
      const timeB = new Date(b.sentAt || b.timestamp || 0).getTime();
      return timeA - timeB;
    });
  };
  const fetchConversationData = async (
    page: number = 1,
    isLoadMore: boolean = false
  ) => {
    console.log("Chat screen - fetchConversationData called with:", {
      conversationId,
      userProfile: !!userProfile,
      page,
      isLoadMore,
    });

    if (!conversationId || !userProfile) {
      console.log("Chat screen - Missing conversationId or userProfile:", {
        conversationId,
        userProfile: !!userProfile,
      });
      return;
    }

    if (
      conversationId === "undefined" ||
      conversationId === "null" ||
      conversationId === ""
    ) {
      console.log("Chat screen - Invalid conversationId:", conversationId);
      setConversationError("Invalid conversation ID");
      return;
    }

    console.log(
      "Chat screen - Starting API fetch for conversation:",
      conversationId,
      "page:",
      page
    );

    if (isLoadMore) {
      setIsLoadingMore(true);
    } else {
      setIsLoadingConversation(true);
      setConversationError(null);
    }

    try {
      console.log(
        "Chat screen - Fetching conversation from API:",
        conversationId,
        "page:",
        page
      );
      console.log("Chat screen - About to call fetchConversationById...");

      let conversationData: ConversationResponse;

      try {
        // Try to fetch conversation details directly with pagination
        conversationData = await fetchConversationById(
          conversationId,
          page,
          50
        );
        console.log(
          "Chat screen - fetchConversationById completed, data:",
          conversationData
        );
      } catch (directError) {
        console.log(
          "Chat screen - Direct fetch failed, trying fallback method:",
          directError
        );

        // Fallback: fetch all conversations and find the one we need
        console.log("Chat screen - Fetching all conversations as fallback...");
        const allConversations = await fetchAllConversations();
        console.log(
          "Chat screen - All conversations fetched:",
          allConversations
        );

        const foundConversation = allConversations.find(
          (conv) => conv.id.toString() === conversationId
        );
        if (foundConversation) {
          console.log(
            "Chat screen - Found conversation in list:",
            foundConversation
          );
          conversationData = foundConversation;
        } else {
          throw new Error(
            `Conversation with ID ${conversationId} not found in conversations list`
          );
        }
      }

      console.log(
        "Chat screen - conversationData.participants:",
        conversationData.participants
      );
      console.log(
        "Chat screen - conversationData.participants length:",
        conversationData.participants?.length
      );
      console.log(
        "Chat screen - conversationData type:",
        typeof conversationData
      );
      console.log("Chat screen - conversationData.id:", conversationData.id);
      console.log(
        "Chat screen - conversationData.id type:",
        typeof conversationData.id
      );
      console.log(
        "Chat screen - Full conversationData structure:",
        JSON.stringify(conversationData, null, 2)
      );

      if (!isLoadMore) {
        setApiConversation(conversationData);
      }

      // Get messages from the conversation data (API includes messages in the response)
      const messagesData: MessageResponse[] = conversationData.messages || [];
      console.log(
        "Chat screen - Messages from conversation data:",
        messagesData
      );

      console.log("Chat screen - API data fetched successfully");
      console.log("Messages data:", messagesData);

      // Handle pagination
      if (isLoadMore) {
        // Load more - prepend older messages
        setAllApiMessages((prev) => [...messagesData, ...prev]);
        setCurrentPage(page);
        setHasMoreMessages(messagesData.length === 50);
      } else {
        // First load - set initial messages
        setAllApiMessages(messagesData);
        setCurrentPage(1);
        setHasMoreMessages(messagesData.length === 50);
      }

      // Convert API data to local conversation format (only on first load)
      if (!isLoadMore) {
        let convertedMessages: Message[] = [];
        let convertedConversation: Conversation;

        try {
          console.log("Chat screen - Converting messages data...");
          convertedMessages = messagesData.map((msg: MessageResponse) => {
            console.log("Chat screen - Converting message:", msg);
            return {
              id: (msg.id || 0).toString(),
              conversationId: (msg.conversationId || 0).toString(),
              senderId: (msg.senderUserId || "system").toString(),
              receiverId: (msg.receiverUserId || "all").toString(),
              type: msg.messageType as any,
              content: msg.content || "",
              timestamp: msg.sentAt || new Date().toISOString(),
              read: !!msg.readAt,
              delivered: !!msg.deliveredAt,
              status: (() => {
                if (msg.readAt) return "read";
                if (msg.deliveredAt) return "delivered";
                return "sent";
              })(),
              metadata: {
                ...msg.metadata,
                fileUrl: msg.fileUrl, // Include fileUrl from API response
                fileName: msg.fileName,
                fileSize: msg.fileSize,
                fileType: msg.fileType,
              },
            };
          });

          console.log("Chat screen - Converting conversation data...");
          convertedConversation = {
            id: (conversationData.id || 0).toString(),
            participants:
              conversationData.participants?.map((p) =>
                (p.id || 0).toString()
              ) || [],
            messages: convertedMessages,
            lastMessage:
              convertedMessages.length > 0
                ? convertedMessages[convertedMessages.length - 1]
                : undefined,
            unreadCount: 0, // This would need to be calculated based on read status
            createdAt: conversationData.createdAt || new Date().toISOString(),
            updatedAt:
              conversationData.updatedAt ||
              conversationData.lastMessageAt ||
              new Date().toISOString(),
            jobId: conversationData.jobId?.toString(),
          };

          console.log("Chat screen - Data conversion successful");
        } catch (conversionError) {
          console.error(
            "Chat screen - Error converting data:",
            conversionError
          );
          throw new Error(`Data conversion failed: ${conversionError.message}`);
        }

        setConversation(convertedConversation);
        console.log(
          "Chat screen - Conversation set successfully:",
          convertedConversation
        );
      }
    } catch (error) {
      console.error("Chat screen - Error fetching conversation data:", error);

      // Check if it's a 404 error (conversation not found)
      if (
        error?.message?.includes("not found") ||
        error?.response?.status === 404
      ) {
        setConversationError(
          "Conversation not found. The conversation may have been deleted or you may not have access to it."
        );
      } else if (error?.message?.includes("Invalid conversation ID")) {
        setConversationError(
          "Invalid conversation ID. Please check the conversation link."
        );
      } else {
        setConversationError(
          error?.message || "Failed to load conversation. Please try again."
        );
      }

      // Fallback to basic conversation if API fails
      const basicConversation: Conversation = {
        id: conversationId,
        participants: [userProfile.id.toString()],
        unreadCount: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        messages: [],
        lastMessage: undefined,
      };

      // Create a mock API conversation for display
      const mockApiConversation: ConversationResponse = {
        id: parseInt(conversationId) || 0,
        chatType: "direct",
        title: `Conversation ${conversationId}`,
        isArchived: false,
        lastMessageAt: new Date().toISOString(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        participants: [
          {
            id: userProfile.id,
            firstName: userProfile.firstName || "",
            middleName: "",
            lastName: userProfile.lastName || "",
            userName: userProfile.userName || "user",
            email: userProfile.email || "",
            profileImage: userProfile.profileImage,
            phoneCountryCode: userProfile.phoneCountryCode,
            phoneNumber: userProfile.phoneNumber,
            verificationStatus: "verified",
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          },
        ],
        messages: [],
        lastMessage: undefined,
      };

      setApiConversation(mockApiConversation);
      setConversation(basicConversation);
    } finally {
      if (isLoadMore) {
        setIsLoadingMore(false);
      } else {
        setIsLoadingConversation(false);
      }
    }
  };
  // Fetch conversation and messages from API
  useEffect(() => {
    console.log("Chat screen - useEffect triggered with:", {
      conversationId,
      userProfile: !!userProfile,
    });

    fetchConversationData();
  }, [conversationId, userProfile]);

  console.log("Chat screen - useEffect dependency check:", {
    conversationId,
    userProfile: !!userProfile,
  });

  // Test API call with hardcoded ID to see if endpoint works
  useEffect(() => {
    const testEndpoint = async () => {
      try {
        console.log("Chat screen - Testing API endpoint with hardcoded ID 44");
        const testData = await fetchConversationById("44");
        console.log("Chat screen - Test API call successful:", testData);
      } catch (error) {
        console.error("Chat screen - Test API call failed:", error);
        console.error("Chat screen - Test error details:", {
          message: error?.message,
          status: error?.response?.status,
          url: error?.config?.url,
        });

        // Test the conversations list endpoint as fallback
        try {
          console.log("Chat screen - Testing conversations list endpoint...");
          const conversationsList = await fetchAllConversations();
          console.log(
            "Chat screen - Conversations list test successful:",
            conversationsList
          );
          console.log(
            "Chat screen - Found conversations:",
            conversationsList.length
          );
        } catch (listError) {
          console.error(
            "Chat screen - Conversations list test failed:",
            listError
          );
        }
      }
    };

    testEndpoint();
  }, []);

  const [message, setMessage] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [showAttachments, setShowAttachments] = useState(false);
  const [googleDocsUrl, setGoogleDocsUrl] = useState("");
  const [docUrl, setDocUrl] = useState("");

  const flatListRef = useRef<FlatList>(null);
  const inputRef = useRef<TextInput>(null);

  // Get the other participant
  const otherParticipantId = Array.isArray(conversation?.participants)
    ? conversation.participants.find(
        (participantId: string) =>
          participantId !== (userProfile?.id || 0).toString()
      )
    : undefined;

  // Get participant info from API data or fallback to mock data
  const otherParticipant = apiConversation?.participants?.find(
    (p) => (p.id || 0).toString() === otherParticipantId
  );

  const merchant = otherParticipant
    ? {
        id: (otherParticipant.id || 0).toString(),
        name:
          otherParticipant.userName ||
          `${otherParticipant.firstName || ""} ${
            otherParticipant.lastName || ""
          }`.trim() ||
          "User",
        avatar: otherParticipant.profileImage,
        email: otherParticipant.email,
        phone: otherParticipant.phoneNumber
          ? `${otherParticipant.phoneCountryCode || ""}${
              otherParticipant.phoneNumber
            }`
          : undefined,
      }
    : mockMerchants.find((m) => m.id === otherParticipantId);

  useEffect(() => {
    if (conversation && conversation.unreadCount > 0) {
      markAsRead(conversation.id);
    }

    const keyboardDidShowListener = Keyboard.addListener(
      "keyboardDidShow",
      () => {
        if (shouldAutoScroll) {
          setTimeout(() => {
            flatListRef.current?.scrollToEnd({ animated: true });
          }, 100);
        }
      }
    );
    const keyboardDidHideListener = Keyboard.addListener(
      "keyboardDidHide",
      () => {
        // Keyboard hidden
      }
    );

    return () => {
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, [conversation]);

  useEffect(() => {
    // Update conversation when it changes
    if (conversationId) {
      console.log(
        "Chat screen - useEffect: Getting conversation for ID:",
        conversationId
      );
      const updatedConversation = getConversation(conversationId);
      console.log(
        "Chat screen - useEffect: Retrieved conversation:",
        updatedConversation
      );
      if (updatedConversation) {
        setConversation(updatedConversation);
        console.log("Chat screen - useEffect: Set conversation state");
      } else {
        console.log(
          "Chat screen - useEffect: No conversation found for ID:",
          conversationId
        );
      }
    }
  }, [conversationId, getConversation]);

  // No need for store updates since we're using API messages as base

  // Join conversation room and listen for socket messages
  useEffect(() => {
    if (!conversationId) return;

    // Import socket service and join conversation room
    import("@app/service/socket-service").then(({ socketService }) => {
      if (socketService.isSocketConnected()) {
        console.log("Chat screen - Joining conversation room:", conversationId);
        socketService.joinConversationRoom(conversationId);

        // Listen for new messages
        const handleNewMessage = (messageData: any) => {
          console.log("Chat screen - Received socket message:", messageData);

          // Check if this message is from the current user (to avoid duplicates)
          const messageSenderId =
            messageData.senderId ||
            messageData.sender_id ||
            messageData.senderUserId ||
            "";
          const isFromCurrentUser =
            String(messageSenderId) === String(userProfile?.id);

          if (isFromCurrentUser) {
            console.log(
              "Chat screen - Ignoring message from current user (already sent):",
              messageData
            );
            return;
          }

          // Convert socket message to Message format
          const socketMessage: Message = {
            id: messageData.id || messageData._id || `socket_${Date.now()}`,
            conversationId:
              messageData.conversationId ||
              messageData.conversation_id ||
              conversationId,
            senderId: messageSenderId,
            receiverId:
              messageData.receiverId ||
              messageData.receiver_id ||
              messageData.receiverUserId ||
              "all",
            type: messageData.messageType || messageData.type || "text",
            content: messageData.content || "",
            timestamp:
              messageData.sentAt ||
              messageData.timestamp ||
              messageData.createdAt ||
              new Date().toISOString(),
            read: false,
            delivered: true,
            status: "delivered",
            jobId: messageData.jobId || messageData.job_id,
            metadata: {
              ...messageData.metadata,
              fileUrl: messageData.fileUrl,
              fileName: messageData.fileName,
              fileSize: messageData.fileSize,
              fileType: messageData.fileType,
            },
          };

          // Add to socket messages
          addSocketMessage(socketMessage);
        };

        // Add event listener
        socketService.socket?.on("new_message", handleNewMessage);

        return () => {
          // Remove event listener
          socketService.socket?.off("new_message", handleNewMessage);
        };
      }
    });

    return () => {
      // Leave conversation room when component unmounts
      import("@app/service/socket-service").then(({ socketService }) => {
        if (socketService.isSocketConnected()) {
          console.log(
            "Chat screen - Leaving conversation room:",
            conversationId
          );
          socketService.leaveConversationRoom(conversationId);
        }
      });
    };
  }, [conversationId]);

  const handleSend = async () => {
    if (!message.trim() || !userProfile || !conversation || !conversationId)
      return;

    const messageContent = message.trim();
    setMessage("");
    setShowAttachments(false);

    // Create temporary message for immediate display
    const tempMessage: Message = {
      id: `temp_${Date.now()}`,
      conversationId: conversationId,
      senderId: userProfile.id.toString(),
      receiverId: otherParticipantId || "all",
      type: "text",
      content: messageContent,
      timestamp: new Date().toISOString(),
      read: false,
      delivered: false,
      status: "sending",
    };

    // Add to socket messages for immediate display
    addSocketMessage(tempMessage);

    try {
      console.log("Chat screen - Sending message via API:", messageContent);

      // Send message via API
      const messageData: SendMessageRequest = {
        content: messageContent,
        messageType: "text",
      };

      const apiResponse = await sendMessageToConversation(
        conversationId,
        messageData
      );
      console.log("Chat screen - Message sent successfully:", apiResponse);

      // Convert API response to local message format
      const newMessage: Message = {
        id: apiResponse.id.toString(),
        conversationId: apiResponse.conversationId.toString(),
        senderId: (apiResponse.senderUserId || userProfile.id).toString(),
        receiverId: (apiResponse.receiverUserId || "all").toString(),
        type: apiResponse.messageType as any,
        content: apiResponse.content,
        timestamp: apiResponse.sentAt,
        read: !!apiResponse.readAt,
        delivered: !!apiResponse.deliveredAt,
        status: (() => {
          if (apiResponse.readAt) return "read";
          if (apiResponse.deliveredAt) return "delivered";
          return "sent";
        })(),
        metadata: apiResponse.metadata,
      };

      // Replace temporary message with real message
      setSocketMessages((prev) =>
        prev.map((msg) => (msg.id === tempMessage.id ? newMessage : msg))
      );

      // Emit message via socket for real-time delivery
      import("@app/service/socket-service").then(({ socketService }) => {
        if (socketService.isSocketConnected()) {
          socketService.emitNewMessage({
            conversationId: conversationId,
            content: messageContent,
            messageType: "text",
            senderId: userProfile.id,
            receiverId: otherParticipantId || "all",
            timestamp: new Date().toISOString(),
          });
        }
      });
    } catch (error) {
      console.error("Chat screen - Error sending message:", error);

      // Update temporary message status to failed
      setSocketMessages((prev) =>
        prev.map((msg) =>
          msg.id === tempMessage.id ? { ...msg, status: "failed" } : msg
        )
      );

      // Emit message via socket for real-time delivery (fallback)
      import("@app/service/socket-service").then(({ socketService }) => {
        if (socketService.isSocketConnected()) {
          socketService.emitNewMessage({
            conversationId: conversationId,
            content: messageContent,
            messageType: "text",
            senderId: userProfile.id,
            receiverId: otherParticipantId || "all",
            timestamp: new Date().toISOString(),
          });
        }
      });
    }

    // Simulate message being delivered after a delay
    setTimeout(() => {
      if (!conversationId) return;

      const updatedConversation = getConversation(conversationId);
      if (updatedConversation) {
        const lastMessage =
          updatedConversation.messages[updatedConversation.messages.length - 1];
        if (lastMessage && lastMessage.senderId === userProfile.id) {
          sendMessage(updatedConversation.id, {
            ...lastMessage,
            status: "delivered",
          });
        }
      }
    }, 1000);

    // Simulate message being read after a delay
    setTimeout(() => {
      if (!conversationId) return;

      const updatedConversation = getConversation(conversationId);
      if (updatedConversation) {
        const lastMessage =
          updatedConversation.messages[updatedConversation.messages.length - 1];
        if (lastMessage && lastMessage.senderId === userProfile.id) {
          sendMessage(updatedConversation.id, {
            ...lastMessage,
            status: "read",
          });
        }
      }

      // Simulate typing
      if (otherParticipantId && conversation) {
        startTyping(conversation.id, otherParticipantId);

        // Simulate response after typing
        setTimeout(() => {
          if (!conversation) return;

          stopTyping(conversation.id, otherParticipantId);

          // Auto response sent - no need to add to store since we're using API messages
        }, 3000);
      }
    }, 2000);
  };

  const getRandomResponse = () => {
    const responses = [
      "Got it, thanks for the update!",
      "I'll check on that and get back to you.",
      "When do you need this delivered by?",
      "Can you provide more details about the shipment?",
      "I'll be there on time, don't worry.",
      "The traffic is a bit heavy, might be delayed by 15 minutes.",
      "Do you have a loading dock at the delivery location?",
      "Is there a specific entrance I should use?",
      "I've arrived at the pickup location.",
      "The cargo is loaded and secured. On my way to delivery now.",
    ];

    return responses[Math.floor(Math.random() * responses.length)];
  };

  const handleInputChange = (text: string) => {
    setMessage(text);

    if (userProfile && conversation) {
      if (text.length > 0) {
        startTyping(conversation.id, userProfile.id);
      } else {
        stopTyping(conversation.id, userProfile.id);
      }
    }
  };

  const handleAttachment = async (type: "image" | "document" | "location") => {
    if (!userProfile || !conversation || !conversationId) return;

    setShowAttachments(false);

    if (type === "image") {
      // Show image picker options
      setShowImagePicker(true);
      return;
    }

    let content = "";
    let messageType = type;
    let fileUrl = "";
    let fileName = "";
    let fileSize = 0;

    switch (type) {
      case "document":
        // Handle document selection with DocumentPicker
        handleDocumentSelection();
        return;
      case "location":
        content = "Location shared: Los Angeles, CA";
        break;
    }

    try {
      console.log("Chat screen - Sending attachment via API:", type);

      // Send attachment via API
      const messageData: SendMessageRequest = {
        content,
        messageType,
        fileUrl: fileUrl || undefined,
        fileName: fileName || undefined,
        fileSize: fileSize || undefined,
      };

      const apiResponse = await sendMessageToConversation(
        conversationId,
        messageData
      );
      console.log("Chat screen - Attachment sent successfully:", apiResponse);

      // Convert API response to local message format
      const newMessage: Message = {
        id: apiResponse.id.toString(),
        conversationId: apiResponse.conversationId.toString(),
        senderId: (apiResponse.senderUserId || userProfile.id).toString(),
        receiverId: (apiResponse.receiverUserId || "all").toString(),
        type: apiResponse.messageType as any,
        content: apiResponse.content,
        timestamp: apiResponse.sentAt,
        read: !!apiResponse.readAt,
        delivered: !!apiResponse.deliveredAt,
        status: (() => {
          if (apiResponse.readAt) return "read";
          if (apiResponse.deliveredAt) return "delivered";
          return "sent";
        })(),
        metadata: apiResponse.metadata,
      };

      // Message sent via API - no need to add to store since we're using API messages
    } catch (error) {
      console.error("Chat screen - Error sending attachment:", error);

      // Fallback: message failed - no need to add to store since we're using API messages
    }
  };

  const handleRecordVoice = async () => {
    if (!userProfile || !conversation || !conversationId) return;

    setIsRecording(!isRecording);

    if (isRecording) {
      // Simulate sending voice message after stopping recording
      const voiceContent = "00:12"; // Duration

      try {
        console.log("Chat screen - Sending voice message via API");

        // Send voice message via API
        const messageData: SendMessageRequest = {
          content: voiceContent,
          messageType: "voice",
          fileName: "voice_message.mp3",
          fileSize: 256000, // 250KB
        };

        const apiResponse = await sendMessageToConversation(
          conversationId,
          messageData
        );
        console.log(
          "Chat screen - Voice message sent successfully:",
          apiResponse
        );

        // Convert API response to local message format
        const newMessage: Message = {
          id: apiResponse.id.toString(),
          conversationId: apiResponse.conversationId.toString(),
          senderId: (apiResponse.senderUserId || userProfile.id).toString(),
          receiverId: (apiResponse.receiverUserId || "all").toString(),
          type: apiResponse.messageType as any,
          content: apiResponse.content,
          timestamp: apiResponse.sentAt,
          read: !!apiResponse.readAt,
          delivered: !!apiResponse.deliveredAt,
          status: (() => {
            if (apiResponse.readAt) return "read";
            if (apiResponse.deliveredAt) return "delivered";
            return "sent";
          })(),
          metadata: apiResponse.metadata,
        };

        // Message sent via API - no need to add to store since we're using API messages
      } catch (error) {
        console.error("Chat screen - Error sending voice message:", error);

        // Fallback: message failed - no need to add to store since we're using API messages
      }
    }
  };

  const handleCall = () => {
    if (otherParticipantId) {
      (navigation as any).navigate("CallScreen", {
        userId: otherParticipantId,
      });
    }
  };

  const loadMoreMessages = () => {
    if (isLoadingMore || !hasMoreMessages) return;

    console.log(
      "Chat screen - Loading more messages, current page:",
      currentPage
    );
    fetchConversationData(currentPage + 1, true);
  };

  const handleImagePickerResponse = (response: ImagePickerResponse) => {
    if (response.didCancel || response.errorMessage) {
      console.log("Image picker cancelled or error:", response.errorMessage);
      setShowImagePicker(false);
      return;
    }

    if (response.assets && response.assets.length > 0) {
      const asset = response.assets[0];
      if (asset.uri) {
        setSelectedImage(asset.uri);
        setImageText("");
        setShowImageModal(true);
        setShowImagePicker(false);
      }
    }
  };

  const handleSelectFromGallery = () => {
    const options = {
      mediaType: "photo" as MediaType,
      includeBase64: false,
      maxHeight: 2000,
      maxWidth: 2000,
      quality: 0.8,
    };

    launchImageLibrary(options, handleImagePickerResponse);
  };

  const handleTakePhoto = () => {
    const options = {
      mediaType: "photo" as MediaType,
      includeBase64: false,
      maxHeight: 2000,
      maxWidth: 2000,
      quality: 0.8,
    };

    launchCamera(options, handleImagePickerResponse);
  };

  // Handle image click to show full screen
  const handleImageClick = (imageUrl: string) => {
    console.log("Chat screen - Image clicked:", imageUrl);
    setFullImageUrl(imageUrl);
    setShowFullImageModal(true);
  };

  // Handle document click to show full screen
  const handleDocumentClick = (documentUrl: string) => {
    setDocUrl(documentUrl);
    // console.log("Chat screen - Document clicked:", documentUrl);
    const googleDocsUrlNew = `https://docs.google.com/viewer?url=${encodeURIComponent(
      documentUrl
    )}&embedded=true`;
    setGoogleDocsUrl(googleDocsUrlNew);
    console.log("Chat screen - Document clicked:", googleDocsUrlNew);
    setFullImageUrl(null); // Clear image URL for documents
    setShowFullImageModal(true);
  };

  // Close full screen image
  const closeFullImageModal = () => {
    setShowFullImageModal(false);
    setFullImageUrl(null);
    setGoogleDocsUrl("");
  };

  // Fallback function to send image directly if upload callback fails
  const handleSendImageDirectly = async (
    imageUri: string,
    messageContent: string,
    tempMessage: Message
  ) => {
    try {
      console.log(
        "Chat screen - Fallback: Sending image directly with local URI"
      );

      const messageData: SendMessageRequest = {
        content: messageContent, // Send text content
        messageType: "file", // Use file type for messages with attachments
        fileUrl: imageUri, // Send image URI in fileUrl field
        fileName: "image.jpg",
        fileSize: 512,
        fileType: "image", // Specify file type as image
      };

      console.log(
        "Chat screen - Fallback: Sending message with local URI:",
        messageData
      );

      const apiResponse = await sendMessageToConversation(
        conversationId,
        messageData
      );

      console.log(
        "Chat screen - Fallback: Message sent successfully:",
        apiResponse
      );

      // Convert API response to local message format
      const newMessage: Message = {
        id: apiResponse.id.toString(),
        conversationId: apiResponse.conversationId.toString(),
        senderId: (apiResponse.senderUserId || userProfile.id).toString(),
        receiverId: (apiResponse.receiverUserId || "all").toString(),
        type: apiResponse.messageType as any,
        content: apiResponse.content, // This will be the text content
        timestamp: apiResponse.sentAt,
        read: !!apiResponse.readAt,
        delivered: !!apiResponse.deliveredAt,
        status: "sent",
        metadata: {
          ...apiResponse.metadata,
          fileUrl: imageUri, // Ensure fileUrl is in metadata
          fileName: "image.jpg",
          fileSize: 512,
          fileType: "image", // Specify file type as image
        },
      };

      // Replace temporary message with real message
      setSocketMessages((prev) =>
        prev.map((msg) => (msg.id === tempMessage.id ? newMessage : msg))
      );

      // Show success message
      showMessage({
        message: "Image sent successfully!",
        type: "success",
      });
    } catch (error) {
      console.error("Chat screen - Fallback: Error sending message:", error);

      // Update temporary message status to failed
      setSocketMessages((prev) =>
        prev.map((msg) =>
          msg.id === tempMessage.id ? { ...msg, status: "failed" } : msg
        )
      );

      showMessage({
        message: "Failed to send image. Please try again.",
        type: "danger",
      });
    } finally {
      setIsUploadingImage(false);
    }
  };

  const handleSendImageWithText = async () => {
    if (!userProfile || !conversation || !conversationId || !selectedImage)
      return;

    const messageContent = imageText.trim() || "Image shared";
    setImageText("");
    setShowImageModal(false);
    setIsUploadingImage(true);

    // Create temporary message for immediate display
    const tempMessage: Message = {
      id: `temp_${Date.now()}`,
      conversationId: conversationId,
      senderId: userProfile.id.toString(),
      receiverId: otherParticipantId || "all",
      type: "file", // Use file type for messages with attachments
      content: messageContent, // Text content for preview
      timestamp: new Date().toISOString(),
      read: false,
      delivered: false,
      status: "sending",
      metadata: {
        fileUrl: selectedImage, // Local URI for preview
        fileName: "image.jpg",
        fileSize: 512,
      },
    };

    // Add to socket messages for immediate display
    addSocketMessage(tempMessage);

    console.log("Chat screen - Starting image upload process");
    console.log("Chat screen - Selected image URI:", selectedImage);
    console.log("Chat screen - Message content:", messageContent);

    // Step 1: Upload image using Redux saga
    const fileData = {
      uri: selectedImage,
      type: "image/jpeg",
      name: "image.jpg",
    };

    console.log(
      "Chat screen - Dispatching uploadFile action with file:",
      fileData
    );

    // Add a fallback timeout in case the callback doesn't work
    const fallbackTimeout = setTimeout(() => {
      console.log(
        "Chat screen - Fallback: Upload callback didn't execute, trying direct approach"
      );
      // Try to send message directly with local URI as fallback
      handleSendImageDirectly(selectedImage, messageContent, tempMessage);
    }, 5000);

    dispatch(
      uploadFile(
        fileData,
        // onSuccess callback
        (uploadResponse: any) => {
          console.log("Chat screen - Upload successful callback triggered");
          console.log("Chat screen - Upload response:", uploadResponse);
          console.log(
            "Chat screen - Upload response type:",
            typeof uploadResponse
          );
          console.log(
            "Chat screen - Upload response keys:",
            Object.keys(uploadResponse || {})
          );

          // Clear the fallback timeout since callback executed
          clearTimeout(fallbackTimeout);

          // Use setTimeout to ensure the callback is executed properly
          setTimeout(async () => {
            try {
              console.log("Chat screen - Starting message sending process");

              // Step 2: Send message with uploaded image URL
              const imageUrl = uploadResponse.data?.url || uploadResponse.url;
              const messageData: SendMessageRequest = {
                content: messageContent, // Send text content
                messageType: "file", // Use file type for messages with attachments
                fileUrl: imageUrl, // Send image URL in fileUrl field
                fileName: uploadResponse.data?.fileName || "image.jpg",
                fileSize: uploadResponse.data?.fileSize || 512,
                fileType: "image", // Specify file type as image
              };

              console.log(
                "Chat screen - Sending message with uploaded image:",
                messageData
              );
              console.log("Chat screen - Conversation ID:", conversationId);

              const apiResponse = await sendMessageToConversation(
                conversationId,
                messageData
              );

              console.log(
                "Chat screen - Message sent successfully:",
                apiResponse
              );

              // Convert API response to local message format
              const newMessage: Message = {
                id: apiResponse.id.toString(),
                conversationId: apiResponse.conversationId.toString(),
                senderId: (
                  apiResponse.senderUserId || userProfile.id
                ).toString(),
                receiverId: (apiResponse.receiverUserId || "all").toString(),
                type: apiResponse.messageType as any,
                content: apiResponse.content, // This will be the text content
                timestamp: apiResponse.sentAt,
                read: !!apiResponse.readAt,
                delivered: !!apiResponse.deliveredAt,
                status: "sent",
                metadata: {
                  ...apiResponse.metadata,
                  fileUrl: imageUrl, // Ensure fileUrl is in metadata
                  fileName: uploadResponse.data?.fileName || "image.jpg",
                  fileSize: uploadResponse.data?.fileSize || 512,
                  fileType: "image", // Specify file type as image
                },
              };

              // Replace temporary message with real message
              setSocketMessages((prev) =>
                prev.map((msg) =>
                  msg.id === tempMessage.id ? newMessage : msg
                )
              );

              // Emit message via socket for real-time delivery
              import("@app/service/socket-service").then(
                ({ socketService }) => {
                  if (socketService.isSocketConnected()) {
                    socketService.emitNewMessage({
                      conversationId: conversationId,
                      content: messageContent, // Send text content
                      messageType: "file",
                      fileUrl: imageUrl, // Send image URL in fileUrl
                      fileType: "image", // Specify file type as image
                    });
                  }
                }
              );

              // Show success message
              showMessage({
                message: "Image sent successfully!",
                type: "success",
              });
            } catch (error) {
              console.error(
                "Chat screen - Error sending message after upload:",
                error
              );

              // Update temporary message status to failed
              setSocketMessages((prev) =>
                prev.map((msg) =>
                  msg.id === tempMessage.id ? { ...msg, status: "failed" } : msg
                )
              );

              showMessage({
                message: "Failed to send message. Please try again.",
                type: "danger",
              });
            } finally {
              setIsUploadingImage(false);
            }
          }, 100); // Small delay to ensure proper execution
        },
        // onError callback
        (error: any) => {
          console.error("Chat screen - Upload failed:", error);

          // Update temporary message status to failed
          setSocketMessages((prev) =>
            prev.map((msg) =>
              msg.id === tempMessage.id ? { ...msg, status: "failed" } : msg
            )
          );

          showMessage({
            message: "Failed to upload image. Please try again.",
            type: "danger",
          });

          setIsUploadingImage(false);
        }
      )
    );
  };

  const handleDocumentSelection = async () => {
    console.log("Chat screen - Opening document picker");

    try {
      // Use @react-native-documents/picker to open file manager
      const result = await pick({
        allowMultiSelection: false,
        type: [
          types.pdf,
          types.doc,
          types.docx,
          types.xls,
          types.xlsx,
          types.images,
        ],
      });

      console.log("Chat screen - DocumentPicker result:", result);

      if (result && result.length > 0) {
        const document = result[0];
        console.log("Document selected:", document);

        // Check if the selected file is an image
        const isImage = document.type && document.type.startsWith("image/");

        if (isImage) {
          // If it's an image, handle it as an image
          setSelectedImage(document.uri);
          setShowImageModal(true);
        } else {
          // Handle as document
          await handleSendDocument({
            uri: document.uri,
            fileName: document.name,
            type: document.type,
            fileSize: document.size,
          });
        }
      }
    } catch (error) {
      console.error("Chat screen - Document picker error:", error);

      // User cancelled picker or error occurred
      if (error.code !== "DOCUMENT_PICKER_CANCELED") {
        console.warn("DocumentPicker error:", error);
        showMessage({
          message: "Failed to select document. Please try again.",
          type: "danger",
        });
      } else {
        console.log("Document selection cancelled by user");
      }
    }
  };

  const handleSendDocument = async (documentAsset: any) => {
    if (!userProfile || !conversation || !conversationId) return;

    const fileName = documentAsset.fileName || `document_${Date.now()}`;
    const fileType = documentAsset.type || "application/octet-stream";
    const fileSize = documentAsset.fileSize || 0;

    console.log("Chat screen - Sending document:", {
      fileName,
      fileType,
      fileSize,
      uri: documentAsset.uri,
    });

    // Create temporary message for immediate display
    const tempMessage: Message = {
      id: `temp_${Date.now()}`,
      conversationId: conversationId,
      senderId: userProfile.id.toString(),
      receiverId: otherParticipantId || "all",
      type: "document",
      content: `Document: ${fileName}`,
      timestamp: new Date().toISOString(),
      read: false,
      delivered: false,
      status: "sending",
      metadata: {
        fileName: fileName,
        fileSize: fileSize,
        fileType: fileType,
        fileUrl: documentAsset.uri,
      },
    };

    // Add to socket messages for immediate display
    addSocketMessage(tempMessage);

    try {
      // Step 1: Upload the document file
      const fileData = {
        uri: documentAsset.uri,
        type: fileType,
        name: fileName,
      };

      console.log("Chat screen - Uploading document file:", fileData);

      // Set a fallback timeout in case the callback doesn't execute
      const fallbackTimeout = setTimeout(() => {
        console.log("Chat screen - Document upload callback timeout");
        updateSocketMessageStatus(tempMessage.id, "failed");
        showMessage({
          message: "Document upload timeout. Please try again.",
          type: "danger",
        });
      }, 10000);

      dispatch(
        uploadFile(
          fileData,
          // onSuccess callback
          (uploadResponse: any) => {
            console.log(
              "Chat screen - Document upload successful:",
              uploadResponse
            );
            clearTimeout(fallbackTimeout);

            // Use setTimeout to ensure the callback is executed properly
            setTimeout(async () => {
              try {
                // Step 2: Send message with uploaded document URL
                const documentUrl =
                  uploadResponse.data?.url || uploadResponse.url;
                const messageData: SendMessageRequest = {
                  content: `Document: ${fileName}`,
                  messageType: "file",
                  fileUrl: documentUrl,
                  fileName: fileName,
                  fileSize: fileSize,
                  fileType: "document",
                };

                console.log(
                  "Chat screen - Sending document message:",
                  messageData
                );

                const apiResponse = await sendMessageToConversation(
                  conversationId,
                  messageData
                );

                console.log(
                  "Chat screen - Document message sent successfully:",
                  apiResponse
                );

                // Convert API response to local message format
                const newMessage: Message = {
                  id: apiResponse.id.toString(),
                  conversationId: apiResponse.conversationId.toString(),
                  senderId: (
                    apiResponse.senderUserId || userProfile.id
                  ).toString(),
                  receiverId: (apiResponse.receiverUserId || "all").toString(),
                  type: apiResponse.messageType as any,
                  content: apiResponse.content,
                  timestamp: apiResponse.sentAt,
                  read: !!apiResponse.readAt,
                  delivered: !!apiResponse.deliveredAt,
                  status: (() => {
                    if (apiResponse.readAt) return "read";
                    if (apiResponse.deliveredAt) return "delivered";
                    return "sent";
                  })(),
                  metadata: {
                    fileName: fileName,
                    fileSize: fileSize,
                    fileType: "document",
                    fileUrl: documentUrl,
                  },
                };

                // Replace temporary message with real message
                replaceSocketMessage(tempMessage.id, newMessage);

                console.log("Chat screen - Document sent successfully");
                showMessage({
                  message: "Document sent successfully!",
                  type: "success",
                });
              } catch (error) {
                console.error(
                  "Chat screen - Error sending document message:",
                  error
                );
                updateSocketMessageStatus(tempMessage.id, "failed");
                showMessage({
                  message: "Failed to send document. Please try again.",
                  type: "danger",
                });
              }
            }, 100);
          },
          // onError callback
          (error: any) => {
            console.error("Chat screen - Document upload failed:", error);
            clearTimeout(fallbackTimeout);
            updateSocketMessageStatus(tempMessage.id, "failed");
            showMessage({
              message: "Failed to upload document. Please try again.",
              type: "danger",
            });
          }
        )
      );
    } catch (error) {
      console.error("Chat screen - Error in document upload process:", error);
      updateSocketMessageStatus(tempMessage.id, "failed");
      showMessage({
        message: "Failed to send document. Please try again.",
        type: "danger",
      });
    }
  };

  // Helper functions for socket message management
  const replaceSocketMessage = (tempId: string, newMessage: Message) => {
    setSocketMessages((prev) =>
      prev.map((msg) => (msg.id === tempId ? newMessage : msg))
    );
  };

  const updateSocketMessageStatus = (
    messageId: string,
    status: MessageStatus
  ) => {
    setSocketMessages((prev) =>
      prev.map((msg) => (msg.id === messageId ? { ...msg, status } : msg))
    );
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    });
  };

  const formatMessageDate = (timestamp: string) => {
    const date = new Date(timestamp);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (date.toDateString() === today.toDateString()) {
      return "Today";
    } else if (date.toDateString() === yesterday.toDateString()) {
      return "Yesterday";
    } else {
      return date.toLocaleDateString("en-US", {
        weekday: "long",
        month: "long",
        day: "numeric",
      });
    }
  };

  const renderMessageStatus = (status?: MessageStatus) => {
    switch (status) {
      case "sent":
        return <Check size={14} color={Colors.white} />;
      case "delivered":
        return <CheckCheck size={14} color={Colors.white} />;
      case "read":
        return <CheckCheck size={14} color={Colors.white} />;
      default:
        return <Clock size={14} color={Colors.white} />;
    }
  };

  const renderMessage = ({
    item,
    index,
  }: {
    item: Message | MessageResponse;
    index: number;
    
  }) => {
    console.log("Chat screen - Rendering messagessss:", item);
    if (!conversation || !userProfile) return null;

    // Convert item to Message format if it's MessageResponse
    const messageItem: Message = {
      id: item.id.toString(),
      conversationId: item.conversationId.toString(),
      senderId:
        (item as any).senderId || (item as any).senderUserId?.toString() || "",
      receiverId:
        (item as any).receiverId ||
        (item as any).receiverUserId?.toString() ||
        "all",
      type: (item as any).type || (item as any).messageType || "text",
      content: (item as any).content || "",
      timestamp:
        (item as any).timestamp ||
        (item as any).sentAt ||
        new Date().toISOString(),
      read: !!(item as any).read || !!(item as any).readAt,
      delivered: !!(item as any).delivered || !!(item as any).deliveredAt,
      status: (item as any).status || "sent",
      metadata: {
        ...((item as any).metadata || {}),
        fileUrl: (item as any).fileUrl || (item as any).metadata?.fileUrl,
        fileName: (item as any).fileName || (item as any).metadata?.fileName,
        fileSize: (item as any).fileSize || (item as any).metadata?.fileSize,
        fileType: (item as any).fileType || (item as any).metadata?.fileType,
      },
    };

    // Debug logging for file messages
    if (messageItem.type === "file" || messageItem.metadata?.fileUrl) {
      console.log("Chat screen - Debug renderMessage file message:", {
        messageId: messageItem.id,
        type: messageItem.type,
        content: messageItem.content,
        metadata: messageItem.metadata,
        originalItem: item,
      });
    }

    // Ensure proper type comparison for isUser
    const isUser = String(messageItem.senderId) === String(userProfile.id);

    // Get all messages for grouping logic
    const allMessages = getAllMessages();
    const showDate =
      index === 0 ||
      formatMessageDate(messageItem.timestamp) !==
        formatMessageDate(allMessages[index - 1]?.timestamp);

    const prevMessage = index > 0 ? allMessages[index - 1] : null;
    const nextMessage =
      index < allMessages.length - 1 ? allMessages[index + 1] : null;

    // For normal array order, first in group is first in array
    const isFirstInGroup =
      !prevMessage || prevMessage.senderId !== messageItem.senderId;
    const isLastInGroup =
      !nextMessage || nextMessage.senderId !== messageItem.senderId;

    // Get sender information from API response
    const senderInfo = apiConversation?.messages?.find(
      (apiMsg) => apiMsg.id.toString() === messageItem.id
    )?.sender;

    const getMessageBubbleStyle = () => {
      if (isUser) {
        return {
          ...styles.messageBubble,
          ...styles.userMessageBubble,
          ...(isFirstInGroup && isLastInGroup
            ? styles.singleMessageBubble
            : {}),
          ...(isFirstInGroup && !isLastInGroup
            ? styles.firstMessageBubble
            : {}),
          ...(!isFirstInGroup && isLastInGroup ? styles.lastMessageBubble : {}),
          ...(!isFirstInGroup && !isLastInGroup
            ? styles.middleMessageBubble
            : {}),
        };
      } else {
        return {
          ...styles.messageBubble,
          ...styles.otherMessageBubble,
          ...(isFirstInGroup && isLastInGroup
            ? styles.singleMessageBubble
            : {}),
          ...(isFirstInGroup && !isLastInGroup
            ? styles.firstMessageBubble
            : {}),
          ...(!isFirstInGroup && isLastInGroup ? styles.lastMessageBubble : {}),
          ...(!isFirstInGroup && !isLastInGroup
            ? styles.middleMessageBubble
            : {}),
        };
      }
    };

    return (
      <View>
        {/* {showDate && (
          <View style={styles.dateContainer}>
            <Text style={styles.dateText}>
              {formatMessageDate(messageItem.timestamp)}
            </Text>
          </View>
        )} */}

        <View
          style={[
            styles.messageContainer,
            isUser ? styles.userMessageContainer : styles.otherMessageContainer,
            // Debug: Add background color to see alignment
            // { backgroundColor: isUser ? 'rgba(0, 255, 0, 0.1)' : 'rgba(255, 0, 0, 0.1)' }
          ]}
        >
          {!isUser && (
            <View style={styles.avatarContainer}>
              {senderInfo?.profileImage ? (
                <Image
                  source={{ uri: senderInfo.profileImage }}
                  style={styles.avatar}
                />
              ) : (
                <View style={styles.avatarFallback}>
                  <Text style={styles.avatarText}>
                    {senderInfo?.name.charAt(0) || "?"}
                  </Text>
                </View>
              )}
            </View>
          )}

          <View
            style={[
              styles.messageContent,
              isUser ? styles.userMessageContent : styles.otherMessageContent,
            ]}
          >
            {messageItem.type === "text" && (
              <View style={getMessageBubbleStyle()}>
                <Text style={styles.messageText}>{messageItem.content}</Text>
                {/* Debug: Show if this is detected as user message */}

                <View style={styles.messageTimeContainer}>
                  <Text style={styles.messageTime}>
                    {formatTime(messageItem.timestamp)}
                  </Text>
                  {isUser && (
                    <View style={styles.messageStatus}>
                      {renderMessageStatus(messageItem.status)}
                    </View>
                  )}
                </View>
              </View>
            )}

            {/* Image and file messages */}
            {(() => {
              const hasFileUrl =
                messageItem.metadata?.fileUrl || (messageItem as any).fileUrl;
              const isImageType = messageItem.type === "image";
              const isFileType = messageItem.type === "file";
              const hasImageInContent =
                isImageType &&
                messageItem.content &&
                messageItem.content.startsWith("http");

              console.log("Chat screen - Debug file message:", {
                messageId: messageItem.id,
                type: messageItem.type,
                hasFileUrl: !!hasFileUrl,
                fileUrl: hasFileUrl,
                metadata: messageItem.metadata,
                isImageType,
                isFileType,
                hasImageInContent,
                shouldRender:
                  (isFileType && hasFileUrl) ||
                  (isImageType && (hasFileUrl || hasImageInContent)),
              });

              return (
                (isFileType && hasFileUrl) ||
                (isImageType && (hasFileUrl || hasImageInContent))
              );
            })() && (
              <View
                style={[getMessageBubbleStyle(), styles.imageMessageBubble]}
              >
                <TouchableOpacity
                  onPress={() => {
                    const fileUrl = messageItem.metadata?.fileUrl ||
                      (messageItem as any).fileUrl ||
                      (messageItem.type === "image" ? messageItem.content : null);
                    
                    // Check metadata.fileType to determine if it's image or document
                    if (messageItem.metadata?.fileType === "document") {
                      handleDocumentClick(fileUrl);
                    } else {
                      handleImageClick(fileUrl);
                    }
                  }}
                  style={{...styles.imageContainer}}
                >
             { messageItem.metadata?.fileType === "document" ?
             <View style={{height:'auto',width:300,flexDirection:'row',padding:10,alignItems:'center',justifyContent:'center'}}>
             <File size={30} color={Colors.white} />

             </View>
             
             :<Image
                    source={{
                      uri:
                        messageItem.metadata?.fileUrl ||
                        (messageItem as any).fileUrl ||
                        (messageItem.type === "image"
                          ? messageItem.content
                          : 'null'),
                    }}
                    style={styles.messageImage}
                    resizeMode="cover"
                  />}
                </TouchableOpacity>
                {messageItem.content && messageItem.content.trim() && (
                  <Text style={styles.messageText}>{messageItem.content}</Text>
                )}
                <View style={styles.messageTimeContainer}>
                  <Text style={styles.messageTime}>
                    {formatTime(messageItem.timestamp)}
                  </Text>
                  {isUser && (
                    <View style={styles.messageStatus}>
                      {renderMessageStatus(messageItem.status)}
                    </View>
                  )}
                </View>
              </View>
            )}

            {messageItem.type === "voice" && (
              <View
                style={[getMessageBubbleStyle(), styles.voiceMessageBubble]}
              >
                <View style={styles.voiceMessageContent}>
                  <Mic
                    size={20}
                    color={isUser ? Colors.white : Colors.primary}
                  />
                  <View style={styles.voiceWaveform}>
                    {Array.from({ length: 10 }).map((_, i) => (
                      <View
                        key={`waveform-${i}-${item.id}`}
                        style={[
                          styles.voiceWaveformBar,
                          {
                            height: 5 + Math.random() * 15,
                            backgroundColor: isUser
                              ? Colors.white
                              : Colors.primary,
                          },
                        ]}
                      />
                    ))}
                  </View>
                  <Text
                    style={[
                      styles.voiceDuration,
                      { color: isUser ? Colors.white : Colors.primary },
                    ]}
                  >
                    {messageItem.content}
                  </Text>
                </View>
                <View style={styles.messageTimeContainer}>
                  <Text style={styles.messageTime}>
                    {formatTime(messageItem.timestamp)}
                  </Text>
                  {isUser && (
                    <View style={styles.messageStatus}>
                      {renderMessageStatus(messageItem.status)}
                    </View>
                  )}
                </View>
              </View>
            )}

            {messageItem.type === "document" && (
              <View style={styles.compactDocumentBubble}>
                <TouchableOpacity
                  style={styles.compactDocumentContainer}
                  onPress={() => {
                    const fileUrl = messageItem.metadata?.fileUrl;
                    if (fileUrl) {
                      handleDocumentClick(fileUrl);
                    } else {
                      showMessage({
                        message: 'Error',
                        description: 'File URL not available',
                        type: 'danger',
                      });
                    }
                  }}
                  activeOpacity={0.7}
                >
                  <View style={styles.compactDocumentIcon}>
                    <File
                      size={20}
                      color={isUser ? Colors.white : Colors.primary}
                    />
                  </View>
                  <Text
                    style={styles.compactDocumentName}
                    numberOfLines={1}
                  >
                    {messageItem.content}
                  </Text>
                </TouchableOpacity>
                <View style={styles.messageTimeContainer}>
                  <Text style={styles.messageTime}>
                    {formatTime(messageItem.timestamp)}
                  </Text>
                  {isUser && (
                    <View style={styles.messageStatus}>
                      {renderMessageStatus(messageItem.status)}
                    </View>
                  )}
                </View>
              </View>
            )}

            {messageItem.type === "location" && (
              <View
                style={[getMessageBubbleStyle(), styles.locationMessageBubble]}
              >
                <View style={styles.locationContainer}>
                  <View style={styles.locationHeader}>
                    <MapPin
                      size={16}
                      color={isUser ? Colors.white : Colors.primary}
                    />
                    <Text
                      style={[
                        styles.locationText,
                        { color: isUser ? Colors.white : Colors.text },
                      ]}
                    >
                      {messageItem.content}
                    </Text>
                  </View>
                  <Image
                    source={{
                      uri: "https://maps.googleapis.com/maps/api/staticmap?center=Los+Angeles,CA&zoom=13&size=300x150&maptype=roadmap&markers=color:red%7CLos+Angeles,CA&key=YOUR_API_KEY",
                    }}
                    style={styles.locationMap}
                    resizeMode="cover"
                  />
                </View>
                <View style={styles.messageTimeContainer}>
                  <Text style={styles.messageTime}>
                    {formatTime(messageItem.timestamp)}
                  </Text>
                  {isUser && (
                    <View style={styles.messageStatus}>
                      {renderMessageStatus(messageItem.status)}
                    </View>
                  )}
                </View>
              </View>
            )}

            {messageItem.type === "system" && (
              <View style={styles.systemMessageContainer}>
                <Text style={styles.systemMessageText}>
                  {messageItem.content}
                </Text>
              </View>
            )}
          </View>

          {!isUser && isFirstInGroup && <View style={styles.spacer} />}
        </View>
      </View>
    );
  };

  const renderTypingIndicator = () => {
    if (
      !conversation ||
      !otherParticipantId ||
      !isTyping(conversation.id, otherParticipantId)
    ) {
      return null;
    }

    return (
      <View style={styles.typingContainer}>
        <View style={styles.typingBubble}>
          <View style={styles.typingDots}>
            <View style={[styles.typingDot, styles.typingDot1]} />
            <View style={[styles.typingDot, styles.typingDot2]} />
            <View style={[styles.typingDot, styles.typingDot3]} />
          </View>
        </View>
      </View>
    );
  };

  const renderEmptyState = () => (
    <View style={styles.emptyStateContainer}>
      <View style={styles.emptyStateContent}>
        <Text style={styles.emptyStateTitle}>Start a conversation</Text>
        <Text style={styles.emptyStateText}>
          Send a message to begin your chat in{" "}
          {apiConversation?.title || merchant?.name || "this conversation"}
        </Text>
      </View>
    </View>
  );

  const renderAttachmentOptions = () => {
    if (!showAttachments) return null;

    return (
      <View style={styles.attachmentContainer}>
        <TouchableOpacity
          style={styles.attachmentOption}
          onPress={() => handleAttachment("image")}
        >
          <View
            style={[
              styles.attachmentIconContainer,
              { backgroundColor: "#4CAF50" + "30" },
            ]}
          >
            <ImageIcon size={24} color="#4CAF50" />
          </View>
          <Text style={styles.attachmentText}>{t("common.image")}</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.attachmentOption}
          onPress={() => handleAttachment("document")}
        >
          <View
            style={[
              styles.attachmentIconContainer,
              { backgroundColor: "#2196F3" + "30" },
            ]}
          >
            <File size={24} color="#2196F3" />
          </View>
          <Text style={styles.attachmentText}>
            {t("messages.messageTypes.document")}
          </Text>
        </TouchableOpacity>

        {/* <TouchableOpacity
          style={styles.attachmentOption}
          onPress={() => handleAttachment("location")}
        >
          <View
            style={[
              styles.attachmentIconContainer,
              { backgroundColor: "#F44336" + "30" },
            ]}
          >
            <MapPin size={24} color="#F44336" />
          </View>
          <Text style={styles.attachmentText}>
            {t("messages.messageTypes.location")}
          </Text>
        </TouchableOpacity> */}
      </View>
    );
  };

  if (!userProfile) {
    console.log(
      "Chat screen - showing loading state. UserProfile:",
      !!userProfile
    );
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={Colors.primary} />
        <Text style={{ color: Colors.white, marginTop: 10 }}>
          Loading user profile...
        </Text>
      </View>
    );
  }

  if (isLoadingConversation) {
    console.log("Chat screen - showing loading state for conversation");
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={Colors.primary} />
        <Text style={{ color: Colors.white, marginTop: 10 }}>
          Loading conversation...
        </Text>
      </View>
    );
  }

  if (conversationError) {
    console.log("Chat screen - showing error state:", conversationError);
    return (
      <View style={styles.loadingContainer}>
        <Text
          style={{ color: Colors.white, marginBottom: 10, textAlign: "center" }}
        >
          Error loading conversation
        </Text>
        <Text
          style={{
            color: Colors.textSecondary,
            textAlign: "center",
            marginBottom: 10,
          }}
        >
          {conversationError}
        </Text>

        {/* Debug info */}
        <Text
          style={{
            color: Colors.textSecondary,
            textAlign: "center",
            marginBottom: 10,
            fontSize: 12,
          }}
        >
          Debug Info:
        </Text>
        <Text
          style={{
            color: Colors.textSecondary,
            textAlign: "center",
            marginBottom: 5,
            fontSize: 10,
          }}
        >
          Conversation ID: {conversationId}
        </Text>
        <Text
          style={{
            color: Colors.textSecondary,
            textAlign: "center",
            marginBottom: 5,
            fontSize: 10,
          }}
        >
          User Profile: {userProfile ? "Loaded" : "Not loaded"}
        </Text>
        <Text
          style={{
            color: Colors.textSecondary,
            textAlign: "center",
            marginBottom: 20,
            fontSize: 10,
          }}
        >
          API Conversation: {apiConversation ? "Loaded" : "Not loaded"}
        </Text>

        <View style={{ flexDirection: "row", gap: 10 }}>
          <TouchableOpacity
            style={{
              backgroundColor: Colors.primary,
              paddingHorizontal: 20,
              paddingVertical: 10,
              borderRadius: 8,
              flex: 1,
            }}
            onPress={() => {
              console.log("Chat screen - Retry button pressed");
              setConversationError(null);
              setConversation(undefined);
              // The useEffect will trigger again when conversation changes
            }}
          >
            <Text style={{ color: Colors.white, textAlign: "center" }}>
              Retry
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              backgroundColor: Colors.textSecondary,
              paddingHorizontal: 20,
              paddingVertical: 10,
              borderRadius: 8,
              flex: 1,
            }}
            onPress={() => {
              console.log("Chat screen - Continue Anyway button pressed");
              setConversationError(null);
              // Create a basic conversation to continue
              const basicConversation: Conversation = {
                id: conversationId,
                participants: [userProfile?.id?.toString() || "1"],
                unreadCount: 0,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
                messages: [],
                lastMessage: undefined,
              };
              setConversation(basicConversation);
            }}
          >
            <Text style={{ color: Colors.white, textAlign: "center" }}>
              Continue Anyway
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  // if (!conversation) {
  //   console.log('Chat screen - no conversation found');
  //   return (
  //     <View style={styles.loadingContainer}>
  //       <Text style={{ color: Colors.white, marginTop: 10 }}>
  //         No conversation found
  //       </Text>
  //     </View>
  //   );
  // }
  const ParticipantAvatar = ({ profileImage }: { profileImage?: string }) => {
    const [error, setError] = useState(false);

    return (
      <Image
        source={
          error || !profileImage
            ? require("../../../assets/dummyImage.png") // 👈 fallback dummy image
            : { uri: profileImage }
        }
        onError={() => setError(true)}
        style={styles.participantAvatarImage}
      />
    );
  };
  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      keyboardVerticalOffset={Platform.OS === "ios" ? 90 : 0}
    >
      <View style={styles.header}>
        <TouchableOpacity
          style={{ paddingHorizontal: 10, paddingVertical: 10 }}
          onPress={() => navigation.goBack()}
        >
          <ArrowLeft size={24} color={Colors.white} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.headerProfile}
          onPress={() => {
            // Navigate to group details screen
            console.log("Navigate to group details:", conversationId);

            if (conversation && apiConversation) {
              (navigation as any).navigate("GroupDetailsScreen", {
                conversation: apiConversation, // Use API conversation data which includes participants
                participants: [], // Empty array since participants are in conversation.participants
                title: conversationItem?.title || selectedParticipant?.userName,
                createdDate: conversationItem.createdAt,
                lastActivity: conversationItem.updatedAt,
                conversationId: conversationId,
              });
            } else {
              // Fallback: Navigate with mock data for testing
              console.log(
                "Chat screen - Using fallback data for GroupDetailsScreen"
              );
              (navigation as any).navigate("GroupDetailsScreen", {
                conversation: apiConversation || {
                  id: conversationId,
                  title:
                    conversationItem?.title || selectedParticipant?.userName,
                  createdAt: new Date().toISOString(),
                  updatedAt: new Date().toISOString(),
                },
                participants: [], // Empty array will trigger fallback participants
                title: conversationItem?.title || selectedParticipant?.userName,
                createdDate:
                  apiConversation?.createdAt || new Date().toISOString(),
                lastActivity:
                  apiConversation?.lastMessageAt ||
                  apiConversation?.updatedAt ||
                  new Date().toISOString(),
              });
            }
          }}
        >
          <View>
            <ParticipantAvatar
              profileImage={selectedParticipant?.profileImage}
            />

            {(() => {
              const participantStatus = getOtherParticipantStatus();
              if (participantStatus?.isOnline) {
                return <View style={styles.onlineIndicator} />;
              }
              return null;
            })()}
          </View>

          {/* {selectedParticipant?.profileImage ? (
            <Image
              source={{ uri: selectedParticipant.profileImage }}
              style={styles.headerAvatar}
            />
          ) : merchant?.avatar ? (
            <Image
              source={{ uri: merchant.avatar }}
              style={styles.headerAvatar}
            />
          ) : (
            <View style={styles.headerAvatarFallback}>
              <Text style={styles.headerAvatarText}>
                {selectedParticipant
                  ? (
                      selectedParticipant.firstName ||
                      selectedParticipant.userName ||
                      "?"
                    )
                      .charAt(0)
                      .toUpperCase()
                  : (apiConversation?.title || merchant?.name || "?")
                      .charAt(0)
                      .toUpperCase()}
              </Text>
            </View>
          )} */}

          <View style={styles.headerInfo}>
            <View style={styles.headerNameContainer}>
              <Text style={styles.headerName}>
                {selectedParticipant
                  ? `${selectedParticipant.userName || "User"}`
                  : conversationItem?.title ||
                    selectedParticipant?.userName ||
                    "User"}
              </Text>
              {/* {(() => {
                const participantStatus = getOtherParticipantStatus();
                if (participantStatus?.isOnline) {
                  return <View style={styles.onlineIndicator} />;
                }
                return null;
              })()} */}
            </View>
            <Text style={styles.headerStatus}>
              {(() => {
                const participantStatus = getOtherParticipantStatus();
                if (participantStatus) {
                  return participantStatus.isOnline
                    ? "Online"
                    : participantStatus.lastSeen || "Offline";
                }
                return selectedParticipant
                  ? selectedParticipant.isOnline
                    ? "Online"
                    : selectedParticipant.lastSeen || "Offline"
                  : otherParticipantId &&
                    isTyping(conversation.id, otherParticipantId)
                  ? t("messages.typing")
                  : t("messages.online");
              })()}
            </Text>
          </View>
        </TouchableOpacity>

        <View style={styles.headerActions}>
          <TouchableOpacity style={styles.headerButton} onPress={handleCall}>
            <Phone size={20} color={Colors.white} />
          </TouchableOpacity>

          <TouchableOpacity style={styles.headerButton}>
            <MoreVertical size={20} color={Colors.white} />
          </TouchableOpacity>
        </View>
      </View>

      <FlatList
        ref={flatListRef}
        data={getAllMessages()}
        keyExtractor={(item) => item.id}
        renderItem={renderMessage}
        contentContainerStyle={styles.messagesList}
        onScroll={handleScroll}
        scrollEventThrottle={16}
        onContentSizeChange={() => {
          // Only auto-scroll if user is at bottom or it's a new message
          if (shouldAutoScroll && isUserAtBottom) {
            flatListRef.current?.scrollToEnd({ animated: true });
          }
        }}
        onLayout={() => {
          // Only auto-scroll on initial load
          if (shouldAutoScroll) {
            flatListRef.current?.scrollToEnd({ animated: false });
          }
        }}
        ListFooterComponent={renderTypingIndicator}
        ListEmptyComponent={renderEmptyState}
        onEndReached={loadMoreMessages}
        onEndReachedThreshold={0.1}
        ListHeaderComponent={
          isLoadingMore ? (
            <View style={styles.loadingMoreContainer}>
              <ActivityIndicator size="small" color={Colors.primary} />
              <Text style={styles.loadingMoreText}>
                Loading more messages...
              </Text>
            </View>
          ) : null
        }
        showsVerticalScrollIndicator={false}
      />

      {/* Scroll to Bottom Button */}
      {!isUserAtBottom && (
        <TouchableOpacity
          style={styles.scrollToBottomButton}
          onPress={scrollToBottom}
        >
          <ArrowLeft
            size={20}
            color={Colors.white}
            style={{ transform: [{ rotate: "-90deg" }] }}
          />
        </TouchableOpacity>
      )}

      {renderAttachmentOptions()}

      {/* Image Selection Modal */}
      <Modal
        visible={showImageModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowImageModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.imageModalContainer}>
            <View style={styles.imageModalHeader}>
              <Text style={styles.imageModalTitle}>Send Image</Text>
              <TouchableOpacity
                onPress={() => setShowImageModal(false)}
                style={styles.imageModalCloseButton}
              >
                <Text style={styles.imageModalCloseText}>✕</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.imagePreviewContainer}>
              {selectedImage && (
                <Image
                  source={{ uri: selectedImage }}
                  style={styles.imagePreview}
                  resizeMode="cover"
                />
              )}
            </View>

            <View style={styles.imageTextInputContainer}>
              <TextInput
                style={styles.imageTextInput}
                placeholder="Add a caption (optional)"
                value={imageText}
                onChangeText={setImageText}
                multiline
                maxLength={500}
              />
            </View>

            <View style={styles.imageModalActions}>
              <TouchableOpacity
                style={styles.imageModalCancelButton}
                onPress={() => setShowImageModal(false)}
                disabled={isUploadingImage}
              >
                <Text style={styles.imageModalCancelText}>Cancel</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[
                  styles.imageModalSendButton,
                  isUploadingImage && styles.imageModalSendButtonDisabled,
                ]}
                onPress={handleSendImageWithText}
                disabled={isUploadingImage}
              >
                {isUploadingImage ? (
                  <View style={styles.imageModalLoadingContainer}>
                    <ActivityIndicator size="small" color={Colors.white} />
                    <Text style={styles.imageModalSendText}>Uploading...</Text>
                  </View>
                ) : (
                  <Text style={styles.imageModalSendText}>Send</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Image Picker Options Modal */}
      <Modal
        visible={showImagePicker}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowImagePicker(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.imagePickerModalContainer}>
            <View style={styles.imagePickerModalHeader}>
              <Text style={styles.imagePickerModalTitle}>Select Image</Text>
              <TouchableOpacity
                onPress={() => setShowImagePicker(false)}
                style={styles.imagePickerModalCloseButton}
              >
                <Text style={styles.imagePickerModalCloseText}>✕</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.imagePickerOptions}>
              <TouchableOpacity
                style={styles.imagePickerOption}
                onPress={handleSelectFromGallery}
              >
                <View
                  style={[
                    styles.imagePickerIconContainer,
                    { backgroundColor: "#4CAF50" + "30" },
                  ]}
                >
                  <ImageIcon size={32} color="#4CAF50" />
                </View>
                <Text style={styles.imagePickerOptionText}>Gallery</Text>
                <Text style={styles.imagePickerOptionSubtext}>
                  Choose from photos
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.imagePickerOption}
                onPress={handleTakePhoto}
              >
                <View
                  style={[
                    styles.imagePickerIconContainer,
                    { backgroundColor: "#2196F3" + "30" },
                  ]}
                >
                  <Camera size={32} color="#2196F3" />
                </View>
                <Text style={styles.imagePickerOptionText}>Camera</Text>
                <Text style={styles.imagePickerOptionSubtext}>
                  Take a photo
                </Text>
              </TouchableOpacity>
            </View>

            <TouchableOpacity
              style={styles.imagePickerCancelButton}
              onPress={() => setShowImagePicker(false)}
            >
              <Text style={styles.imagePickerCancelText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Full Screen Image Modal */}
      <Modal
        visible={showFullImageModal}
        transparent={true}
        animationType="fade"
      >
        <View style={styles.fullImageModalOverlay}>
          <View style={styles.fullImageModalContainer}>
            {/* Header with close button */}
            <View style={styles.fullImageHeader}>
              {/* Show download button only for documents */}
              {!fullImageUrl && (
                <TouchableOpacity
                  onPress={() => {downloadFile(docUrl)}}
                  style={styles.fullImageCloseButton}
                >
                  <Download size={24} color={Colors.white} />
                </TouchableOpacity>
              )}
              <TouchableOpacity
                onPress={closeFullImageModal}
                style={styles.fullImageCloseButton}
              >
                <X size={24} color={Colors.white} />
              </TouchableOpacity>
            </View>

             {/* Content */}
             <View style={styles.fullImageContent}>
               {fullImageUrl ? (
                 // Render Image component for images
                 <Image
                   source={{ uri: fullImageUrl }}
                   style={styles.fullImage}
                   resizeMode="contain"
                 />
               ) : (
                 // Render WebView component for documents
                 <WebView
                   source={{ uri: googleDocsUrl }}
                   style={styles.webview}
                   scalesPageToFit={true}
                   javaScriptEnabled={true}
                   domStorageEnabled={true}
                   startInLoadingState={true}
                   allowsFullscreenVideo={true}
                 />
               )}
             </View>
          </View>
        </View>
      </Modal>

      <View style={styles.inputContainer}>
        <TouchableOpacity
          style={styles.attachButton}
          onPress={() => setShowAttachments(!showAttachments)}
        >
          {showAttachments ? (
            <X size={20} color={Colors.primary} />
          ) : (
            <Paperclip size={20} color={Colors.textSecondary} />
          )}
        </TouchableOpacity>

        <View style={styles.textInputContainer}>
          <TextInput
            ref={inputRef}
            style={styles.input}
            placeholder="Type a message..."
            placeholderTextColor={Colors.textSecondary}
            value={message}
            onChangeText={handleInputChange}
            multiline
            maxLength={1000}
          />
        </View>

        {message.trim() ? (
          <TouchableOpacity style={styles.sendButton} onPress={handleSend}>
            <Send size={20} color={Colors.white} />
          </TouchableOpacity>
        ) : (
          <TouchableOpacity
            style={[styles.sendButton, isRecording && styles.recordingButton]}
            onPress={handleRecordVoice}
          >
            <Mic size={20} color={Colors.white} />
          </TouchableOpacity>
        )}
      </View>
    </KeyboardAvoidingView>
  );
}

export { ChatScreen };
