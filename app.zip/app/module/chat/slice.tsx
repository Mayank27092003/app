/**
 * Chat slice
 * @format
 */

import { createAction } from '@reduxjs/toolkit';

export const chat = createAction<{}>('CHAT/CHAT');
