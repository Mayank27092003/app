/**
 * @format
 * Chat Module
 */

import { ChatScreen } from './view/chat';

export { ChatScreen };
