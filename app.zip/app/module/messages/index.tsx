/**
 * @format
 * Message Module
 */

import { MessagesScreen } from './view/messages';

export { MessagesScreen };
