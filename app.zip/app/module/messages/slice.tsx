/**
 * Message slice
 * @format
 */

import { createAction } from '@reduxjs/toolkit';

export const message = createAction<{}>('MESSAGE/MESSAGES');

