import en from './en.json';
import hr from './hr.json';
import es from './es.json';
import de from './de.json';
import ar from './ar.json';
import pt from './pt.json';
import zh from './zh.json';
import hi from './hi.json';
import fr from './fr.json';
import ru from './ru.json';

export { en, hr,es,de,ar,pt,zh,hi,fr,ru};